package eight;
import java.util.*;
public class main {

	public static void main(String[] args) {
		//String details[] = null;
		  String [] details = new String[10];
	       Scanner sc= new Scanner(System.in);
	       Wicked ws=new Wicked();
	       System.out.println("Enter the Number of wickets : ");
	       int wickets=sc.nextInt();
	    for(int i=1;i<=wickets;i++) {
	    	sc.nextLine();
	    	System.out.println("Enter the details : ");
	      // String [] details = new String[10];
	        details[i-1]=sc.nextLine();
	    }
	    for(int i=0;i<wickets;i++) {
	    	String [] str=details[i].split(",");
	    	for(String s:str) 
	    		System.out.println("");
	    	System.out.println("Wicket details : ");
	        String oo=str[0];
	        long over=Long.parseLong(oo);
	        ws.setOver(over);
	        System.out.println("Over : "+ws.getOver());
	        String oo1=str[1];
	        long ball=Long.parseLong(oo1);
	        ws.setBall(ball);
	        System.out.println("Ball : "+ws.getBall());
	        String wiketType=str[2];
	        ws.setWikeType(wiketType);
	        System.out.println("WicketType : "+ws.getWikeType());
	        String playerName=str[3];
	        ws.setPlayerMan(playerName);
	        System.out.println("PlayerNAme : "+ws.getPlayerMan());
	        String bowler=str[4];
	        ws.setBowlerName(bowler);
	        System.out.println("BowlerName : "+ws.getBowlerName());
	        
	        
	    	
	    	
	    	
	    	
	    		 
	    		
	    		 
	    	 }
	    	 
	    	 
	       }
	       
	       


       
       
	}


