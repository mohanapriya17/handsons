package fourth2;
import java.util.*;
public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Event eve=new Event();
		Exhibition ex=new Exhibition();
		StageEvent stage=new StageEvent();
		int n=0;
		while(n<2) {
		
		System.out.println("Enter the name of the event");
		String ename=sc.nextLine();
		eve.setName(ename);
		sc.nextLine();
		//System.out.println(eve.getName());
		System.out.println("Enter the details of the event");
		String details=sc.nextLine();
		eve.setName(details);
		sc.nextLine();
		//System.out.println(eve.getDetails());
		System.out.println("Enter the Owner Name of the event");
		String ownername=sc.nextLine();
		eve.setName(ownername);
		
		eve.menu();
		int ch=sc.nextInt();
		switch(ch) {
		case 1:
			System.out.println("Enter the number of stalls");
			Integer num=sc.nextInt();
			ex.setNoofStall(num);
			System.out.println(ex.Projectedrevenue(num));
			break;
		case 2:
			System.out.println("Enter the number of shows");
			Integer num1=sc.nextInt();
			stage.setNoOfShows(num1);
			System.out.println("Enter the Number of persons");
			Integer num2=sc.nextInt();
			stage.setNoOfSeatPerShow(num2);
			System.out.println(stage.Projectedrevenue(num1, num2));
			break;
		}
		
		
		

	}

}
}
