package javafeatures2;

import java.io.*;
import java.util.function.Function;

public class solve2 {

	public static void main(String[] args) throws IOException {
       BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
       System.out.println("Enter the line");
       String s=br.readLine();
       Function<String,String> f= s1->s1.replaceAll(" ",""); 
       System.out.println(f.apply(s));
       
       
	}

}
