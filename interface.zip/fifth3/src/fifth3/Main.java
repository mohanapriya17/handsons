package fifth3;
import java.util.*;
public class Main {

	public static void main(String[] args) {
         AxisBank Ab=new AxisBank();
       
         Scanner sc=new Scanner(System.in);
         System.out.println("\n 1) Axis Bank \n 2)HDFC \n ICIC");
         System.out.println("Choose the Bank");
         int ch=Integer.parseInt(sc.next());
         switch(ch) {
         case 1:
        	 AxisBank ab=new AxisBank();
        	 ab.duration();
        	 double d=sc.nextDouble();
        	 ab.amount();
        	 double amt=sc.nextDouble();
        	 double total=(d*amt*56)/100;
        	 System.out.println("you will have return as"+total+"in"+d+"years");
        	 
         case 2:
        	 HDFC hc =new HDFC();
        	 hc.duration();
        	 double d1=sc.nextDouble();
        	 hc.amount();
        	 double amt1=sc.nextDouble();
        	 double total1=(d1*amt1*56)/100;
        	 System.out.println("you will have return as"+total1+"in"+d1+"years");
        	 
        	 
         case 3	: 
        	ICIC ic=new ICIC();
        	ic.duration();
        	 double d3=sc.nextDouble();
        	 ic.amount();
        	 double amt2=sc.nextInt();
        	 double total2=(d3*amt2*56)/100;
        	 System.out.println("you will have return as"+total2+"in"+d3+"years");
        	 
        	 
        	 
         }
         
         
        
	}

}
