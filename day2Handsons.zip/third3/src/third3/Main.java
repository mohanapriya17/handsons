package third3;
import java.util.*;
public class Main {

	public static void main(String[] args) {
          Scanner sc=new Scanner(System.in);
          Stall st=new Stall();
          System.out.println("Enter the name of the stall");
          String s=sc.nextLine();
          st.setName(s);
          System.out.println("Enter the details of the stall");
          String s0=sc.nextLine();
          st.setDetail(s0);
          System.out.println("Enter the owwner name of the stall");
          String s1=sc.nextLine();
          st.setOwnername(s1);
          System.out.println("Enter stall Type");
          String s2=sc.nextLine();
          System.out.println("enter the sqarefeet");
          Integer squareFeet=sc.nextInt();
       //  System.out.println( "Enter the stall price"+st.computeCost(s2, squareFeet));
         System.out.println("Does the stall have Tv?(y/n)");
         sc.nextLine();
         String s3=sc.next();
         if(s3.equals("y")) {
        	 System.out.println("Enter number of Tv");
        	 int num=sc.nextInt();
        	 double d=st.computeCost(s2, squareFeet, num);
        	 System.out.println("the cost of the stall is"+d);
         }
         else {
        	 double a=st.computeCost(s2,squareFeet);
         }
	}

}
