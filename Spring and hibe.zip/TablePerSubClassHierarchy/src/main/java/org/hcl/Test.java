package org.hcl;

import org.hcl.entities.BatsMan;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {

	public static void main(String[] args) {
		Configuration configuration=new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory factory=configuration.buildSessionFactory();
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		BatsMan batsMan=new BatsMan();
		batsMan.setPersonId(1);
		batsMan.setFirstName("dhoni");
		batsMan.setLastName("MS");
		batsMan.setBattingHand("right");
		batsMan.setHighestScore(100);
		session.persist(batsMan);
		transaction.commit();
		session.close();
	}

}
