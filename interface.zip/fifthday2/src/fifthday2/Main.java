package fifthday2;
import java.util.*;
public class Main {

	public static void main(String[] args) {
      Scanner sc=new Scanner(System.in);
      
      ramachi ra=new ramachi();
      shivagh sh=new shivagh();
      murud mu=new murud();
      ra.menu();
      	System.out.println("");
	       int ch1=sc.nextInt();
	        switch(ch1) {
	        
	        case 1: System.out.println("After choosing ramchi");
	                ra.distance();
	                break;
	        case 2: System.out.println("After choosing shivagh");
            sh.distance();
            break;
	        case 3: System.out.println("After choosing Murud");
            mu.distance();
            break;
            
            
	                
	        	
	}

}
}
