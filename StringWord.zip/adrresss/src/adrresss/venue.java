package adrresss;

public class venue {
	String name;
	String city;

}
