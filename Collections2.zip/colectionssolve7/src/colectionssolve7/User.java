package colectionssolve7;

import java.util.Comparator;

public class User implements Comparable{
private String name,mobileNumber,userName,password;

public User() {
	super();
	// TODO Auto-generated constructor stub
}


public User(String name, String mobileNumber, String userName, String password) {
	super();
	this.name = name;
	this.mobileNumber = mobileNumber;
	this.userName = userName;
	this.password = password;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getMobileNumber() {
	return mobileNumber;
}

public void setMobileNumber(String mobileNumber) {
	this.mobileNumber = mobileNumber;
}

public String getUserName() {
	return userName;
}

public void setUserName(String userName) {
	this.userName = userName;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}


@Override
public String toString() {
	
	System.out.format("%-15s%-15s"+name,mobileNumber);
	return "";
}


@Override
public int compareTo(Object a) {
	User use=(User)a;
	return name.compareTo(use.getName());
}





}
