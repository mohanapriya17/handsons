package six8;
import java.util.*;
public class Main {

	public static void main(String[] args) {
       Scanner sc=new Scanner(System.in);
       System.out.println("Enter Humpty's Sentence :");
       String s1=sc.nextLine();
       if(s1.equals(s1.toUpperCase())) {
    	   System.out.println("String is in uppercase");
       }
       else {
    	   System.out.println("String is not in uppercase");
       }
	}

}
