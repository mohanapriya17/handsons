package fourth;
import java.util.*;
public class main {

	public static void main(String[] args) {
		Player p=new Player();
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the player details");
      String s=sc.nextLine();
     String [] str=s.split(",");
     for(String oo:str) 
    	 System.out.println(" ");
     System.out.println("Player details");
     
    	 String name=str[0];
    	 p.setName(name);
      	 System.out.println(" PLayer name : "+p.getName());
    	 String country=str[1];
    	 p.setCountry(country);
    	 System.out.println(" Country Name : "+p.getCountry());
    	 
    	 String skill=str[2];
    	 p.setSkill(skill);
    	 //System.out.println(p.getName());
    	// System.out.println(p.getCountry());
    	 System.out.println(" Skill Name : "+p.getSkill());
    
     }
     
	}


