package fifthday2;

public class murud implements Fort{
	
		public void distance() {
			System.out.println("You are going to visit Murud");
			System.out.println("the distance is 93Km");
		}
	}
	


