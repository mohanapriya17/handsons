package fifthday2;

public class shivagh implements Fort{
int distance;


	public void distance() {
		System.out.println("You are going to visit Shivagh");
		System.out.println("the distance is 100Km");
	}
	

protected shivagh() {
	super();
}

}
