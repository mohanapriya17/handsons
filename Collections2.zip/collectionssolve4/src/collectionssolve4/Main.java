package collectionssolve4;
import java.io.*;
import java.util.*;
public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		List<Address> list=new ArrayList<>();
      BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
      System.out.println("Enter the number of users: ");
      int n=Integer.parseInt(br.readLine());
      if(n>0) {
    	  for(int i=0;i<n;i++) {
    		  System.out.println("Enter user address in CSV(Username,AddressLine 1,AddressLine 2,PinCode)");
    		  String s=br.readLine();
    		  String str[]=s.split(",");
    		  list.add(new Address(str[0],str[1],str[2],Integer.parseInt(str[3])));
    		  
    	  }
    	  Collections.sort(list);
    	  System.out.println("User details");
    	  System.out.println();
    	  Iterator<Address> it= list.iterator();
    	  while(it.hasNext()) {
    		  Address add=it.next();
    		  System.out.println(add);
    	  }
      }
      
      
	}

}
