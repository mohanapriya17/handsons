package third2;
import java.util.*;
public class Main {

	public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
    	System.out.println("Enter the Account details");
        String s=sc.nextLine();
        
    	String [] str=s.split(",");
    	for(String oo:str) 
    		System.out.println(" ");
    	  fxedAccount facc=new fxedAccount();
    	  String name=str[0];
    	  facc.setAccount_Number(name);
    	  String oo= str[1];
    	  double bankAccount= Double.parseDouble(oo);
    	  facc.setBalance(bankAccount);
    	  String holderName=str[2];
    	  facc.setAccountHolderName(holderName);
    	  String oo1=str[3];
    	  double minibalance=Double.parseDouble(oo1);
    	  facc.setMinimumBalance(minibalance);
    	  String oo2=str[4];
    	  Integer lockingperiod=Integer.parseInt(oo2);
    	  facc.setLocking_period(lockingperiod);
    	  facc.display();
    	  
    	  
    	
    	
    		
    	
    		
    		
    	
		
	}
	
}

