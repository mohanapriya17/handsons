package secondday;
import java.util.*;
public class Main {

	public static void main(String[] args) {
      Scanner sc=new Scanner(System.in);
      
      
      System.out.println("Product details :");
      sc.nextLine();
      Product pr=new Product();
      Product pr2=new Product();
      System.out.println(" productName :");
      String productName=sc.nextLine();
      pr.setProduct_name(productName);
      sc.nextLine();
      System.out.println(" product code: ");
      int code=sc.nextInt();
      pr.setProduct_code(code);
      System.out.println(" price ");
      double pprice=sc.nextDouble();
      pr.setPrice(pprice);
       System.out.println(" stocks :");
      int stocks=sc.nextInt();
      pr.setStock(stocks);
     
      System.out.println("Enter the product code :");
      int code1=sc.nextInt();
      pr2.setProduct_code(code1);
      sc.nextLine();
      System.out.println("Enter the Product name :");
      String name1=sc.nextLine();
      pr2.setProduct_name(name1);
      sc.nextLine();
      System.out.println("Enter the price :");
      double prices1=sc.nextDouble();
      pr2.setPrice(prices1);
      System.out.println("enter the stocks :");
      int stocks1=sc.nextInt();
      pr2.setStock(stocks1);
    pr.display();
    pr2.display();
    
   Product checkprice=new Product();
   checkprice.checkPrice(pr, pr2);
    
      
      
      
	}

}
