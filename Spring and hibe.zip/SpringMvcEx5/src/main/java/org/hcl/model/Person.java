package org.hcl.model;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;

public class Person {
	@NotNull(message = "Please enter first name")
	private String firstName;
	@Length(min = 3,max = 10,message = "minimum length is 3 to 5 characters")
	private String lastName;
	public Person() {
		// TODO Auto-generated constructor stub
	}
	public Person(String firstName, String lastName) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
}
