package com.ksr;

import java.util.List;

public class College {
	private int cid;
	private String collegeName;
	private List<Course> courses;
	public College() {
		// TODO Auto-generated constructor stub
	}
	public College(int cid, String collegeName, List<Course> courses) {
		super();
		this.cid = cid;
		this.collegeName = collegeName;
		this.courses = courses;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCollegeName() {
		return collegeName;
	}
	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}
	public List<Course> getCourses() {
		return courses;
	}
	public void setCourses(List<Course> courses) {
		this.courses = courses;
	}
	
}
