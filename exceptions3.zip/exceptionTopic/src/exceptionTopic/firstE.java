package exceptionTopic;

public class firstE {
	  int days;
      int n;
	protected int getDays() {
		return days;
	}
	protected void setDays(int days) {
		this.days = days;
	}
	protected int getN() {
		return n;
	}
	protected void setN(int n) {
		this.n = n;
	}
	/**
	 * 
	 */
	protected firstE() {
		super();
	}
}
