package collections9;

public class User {
private String name,contactNumber,username,email;

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getContactNumber() {
	return contactNumber;
}

public void setContactNumber(String contactNumber) {
	this.contactNumber = contactNumber;
}

public String getUsername() {
	return username;
}

public void setUsername(String username) {
	this.username = username;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

/**
 * @param name
 * @param contactNumber
 * @param username
 * @param email
 */
public User(String name, String contactNumber, String username, String email) {
	super();
	this.name = name;
	this.contactNumber = contactNumber;
	this.username = username;
	this.email = email;
}

/**
 * 
 */
public User() {
	super();
	// TODO Auto-generated constructor stub
}
void display() {
	System.out.format("%-20s%-20s%-20s%-20s",name,contactNumber,username,email);
	
	
}
	
}
