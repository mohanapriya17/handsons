package second3;
import java.util.*;
public class Main {
	private static int prods =5;
    public static void main(String[] args) {
       Scanner sc=new Scanner(System.in);
       Product[] prod=new Product[prods];
       
       
       System.out.println("Enter the Products"); 
       for(int i=0;i<prods;i++) {
    	   Product pr1=buildProduct();
    	   prod[i]=pr1;
    	   
    	 }
       System.out.println("Product details");
       for(int i=0;i<prods;i++) {
    	   Product pr1=prod[i];
    	   displayProduct(pr1);
    	   
    	   
       }
       System.out.println("Discount");
         for(int i=0;i<prods;i++) {
        	 System.out.println("discount price"+prod[i].getPrice());
        	
         }
         System.out.println("check the min stock");
        
       
      	
		


}
	public static void displayProduct(Product pr){
		System.out.println("Product_code"+pr.getProduct_code());
		System.out.println("Product_Name"+pr.getProduct_Name());
		System.out.println("product price"+pr.getPrice());
		System.out.println("stocks  :"+pr.getStock());
		
	}
	public static Product buildProduct() {
		Scanner sc=new Scanner(System.in);
		Product pr1=new Product();
		System.out.println("enter the product_code");
		int code=sc.nextInt();
		pr1.setProduct_code(code);
	    sc.nextLine();
	    System.out.println("Enter the product name");
	    String product_name=sc.nextLine();
	    pr1.setProduct_Name(product_name);
	    System.out.println("enter the Product price");
	    double prices=sc.nextDouble();
	    pr1.setPrice(prices);
	    System.out.println("Enter the stocks");
	    int stocks=sc.nextInt();
	     pr1.setStock(stocks);
		return pr1;
		
	}
		
		
	}

