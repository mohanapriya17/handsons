package third2;

public class Account {
	String Account_Number;
	double balance;
	String accountHolderName;
	protected String getAccount_Number() {
		return Account_Number;
	}
	protected void setAccount_Number(String account_Number) {
		Account_Number = account_Number;
	}
	protected double getBalance() {
		return balance;
	}
	protected void setBalance(double balance) {
		this.balance = balance;
	}
	protected String getAccountHolderName() {
		return accountHolderName;
	}
	protected void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	/**
	 * 
	 */
	/**
	 * @param account_Number
	 * @param balance
	 * @param accountHolderName
	 */
	protected Account(String account_Number, double balance, String accountHolderName) {
		super();
		Account_Number = account_Number;
		this.balance = balance;
		this.accountHolderName = accountHolderName;
	}
	/**
	 * 
	 */
	protected Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
