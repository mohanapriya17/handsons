const eventname = new Array();


function push() {
    var input = document.getElementById("EventName").value;
    console.log(input);

    let j = 0;
    for (i = 0; i < eventname.length; i++) {

        if (eventname[i] === input) {
            console.log(eventname);
            document.getElementById("SuccessMessage").innerHTML = "Name already Exists"
            j++;

        } else
            break;
    }

    if (j == 0) {
        let c = eventname.push(input);
        console.log(c);
        console.log(eventname);
        document.getElementById("SuccessMessage").innerHTML = "Successfully Added"
        document.getElementById("EventName").value = "";
    }



}

function pop() {
    document.getElementById("Result_list").innerHTML = ""
    var input = document.getElementById("EventName").value;
    console.log(input);

    let c = eventname.pop(input);
    document.getElementById("SuccessMessage").innerHTML = "Removed Successfully"
    console.log(c);

    if (eventname.length == 0) {
        document.getElementById("SuccessMessage").innerHTML = "The List is Empty"
    }

}


function displayEvent() {

    let s = document.getElementById("Result_list");
    s.style.fontSize = "35px";
    s.style.color = "black";
    s.style.fontWeight = "bolder";
    s.innerHTML = "The Sorted List is"
    for (k = 0; k < eventname.length; k++) {

        document.getElementById("Result_list").innerHTML += " <li > " + eventname[k] + " </li>"
        console.log(eventname[k]);
    }
}