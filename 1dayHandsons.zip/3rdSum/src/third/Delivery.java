package third;

public class Delivery {
long over;
long runs;
long ball;
String batsman;
String bowlerMan;
String nonStriker;


public long getOver() {
	return over;
}


public void setOver(long over) {
	this.over = over;
}


public long getRuns() {
	return runs;
}


public void setRuns(long runs) {
	this.runs = runs;
}


public long getBall() {
	return ball;
}


public void setBall(long ball) {
	this.ball = ball;
}


public String getBatsman() {
	return batsman;
}


public void setBatsman(String batsman) {
	this.batsman = batsman;
}


public String getBowlerMan() {
	return bowlerMan;
}


public void setBowlerMan(String bowlerMan) {
	this.bowlerMan = bowlerMan;
}


public String getNonStriker() {
	return nonStriker;
}


public void setNonStriker(String nonStriker) {
	this.nonStriker = nonStriker;
}


void display() {
	System.out.println("Delivery Details: ");
	System.out.println("over: "+over);
	System.out.println("runs: "+runs);
	System.out.println("batsman: "+batsman);
	System.out.println("bowlerman: "+bowlerMan);
	System.out.println("nonstriker: "+nonStriker);
}
}
