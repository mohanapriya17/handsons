package six3;
import java.util.*;
public class Main {

	public static void main(String[] args) {
     Scanner sc=new Scanner(System.in);
     System.out.println("Enter Humpty's Sentence :");
     String s1=sc.nextLine();
     System.out.println("word to replace :");
     String s2=sc.nextLine();
     System.out.println("Synonym");
     String s3=sc.nextLine();
     System.out.println("Replaced String :"+s1.replaceAll(s2, s3));
     
	}

}
