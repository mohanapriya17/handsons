package exceptiom2;

public class itemType {
	String name;
	double deposit;
	double  costPerDay;
	protected String getName() {
		return name;
	}
	protected void setName(String name) {
		this.name = name;
	}
	protected double getDeposit() {
		return deposit;
	}
	protected void setDeposit(double deposit) {
		this.deposit = deposit;
	}
	protected double getCostPerDay() {
		return costPerDay;
	}
	protected void setCostPerDay(double costPerDay) {
		this.costPerDay = costPerDay;
	}
	
	
	@Override
	public String toString() {
		System.out.println("The details of the type of string"+name+"deposit"+deposit+"Cost per day"+costPerDay);
		return super.toString();
	}
	protected itemType() {
		super();
	}
	protected itemType(String name, double deposit, double costPerDay) {
		super();
		this.name = name;
		this.deposit = deposit;
		this.costPerDay = costPerDay;
	}
	

}
