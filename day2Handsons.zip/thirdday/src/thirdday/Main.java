package thirdday;

import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        
        
       
       savingAccount sacc=new savingAccount();
       currentAccount cacc=new currentAccount();
       sacc.choice();
       System.out.println("Enter the choice");
       int n=0;
      while(n<3) {
     	  int ch=sc.nextInt();
     	  switch(ch) {
     	 
        case 1:
        	System.out.println("Enter the Account details");
        	sc.nextLine();
        	 String s=sc.nextLine();
             String [] str=s.split(",");
             for(String oo:str) 
            	 System.out.println(" ");
             String name= str[0];
            sacc.setAccname(name);
           
            String accno=str[1];
            sacc.setAccno(accno);
          //  System.out.println("Account NUmber   "+sacc.getAccno());
            String bankname=str[2];
            sacc.setBankname(bankname);
           // System.out.println("BankName   "+sacc.getBankname());
            String organization=str[3];
            sacc.setOrg_Name(organization);
            //System.out.println("Organization    "+sacc.getOrg_Name());
           // sacc.choice();
            sacc.display1();
            sc.nextLine();
            sacc.choice();
            break;
            
            
        case 2:
        	System.out.println("Enter the Account details");
        	sc.nextLine();
        	 String s1=sc.nextLine();
             String [] str1=s1.split(",");
             for(String oo:str1) 
            	 System.out.println(" ");
             String name1= str1[0];
            cacc.setAccname(name1);
           // System.out.println("Account Name"+cacc.getAccname());
            String accno1=str1[1];
            cacc.setAccno(accno1);
           // System.out.println("Account NUmber"+cacc.getAccno());
            String bankname1=str1[2];
            cacc.setBankname(bankname1);
           // System.out.println("BankName"+cacc.getBankname());
           String TINnumber=str1[3];
           cacc.setTIN_number(TINnumber);
           //System.out.println("TIN_NUmber"+cacc.getTIN_number());
          // cacc.display();
           cacc.display1();
           break;
           
            
            
             
        	
        	}
        }
          
          
	}
}


