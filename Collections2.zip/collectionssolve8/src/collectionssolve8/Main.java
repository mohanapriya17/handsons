package collectionssolve8;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;


public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		 BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	      List<Address> list=new ArrayList<>();
	      LinkedHashMap<String,List<Address>> map=new LinkedHashMap();
	      LinkedHashMap<String,LinkedHashMap<String,List<Address>>> map1=new LinkedHashMap();
	      System.out.println("Enter the number of user details  ");
	      int s=Integer.parseInt(br.readLine());
	      if(s>0) {
	    	  for(int i=1;i<=s;i++) {
	    		  System.out.println("Enter the address"+i+" detail");
	    		  String sr=br.readLine();
	    		  String[]str=sr.split(",");
	    		  list.add(new Address(str[0],str[1],str[2],str[3],Integer.parseInt(str[4])));
	    		  map.put(str[2], list);
	    		  map1.put(str[3], map);
	    		  
	    	  }
	    	  System.out.println("Enter the state to be searched  :");
	    	  String s1=br.readLine();
	    	  if(map1.containsKey(s1)) {
	    		  System.out.println("Enter the city to be searched");
	    		  String s2=br.readLine();
	    		  if(map.containsKey(s2)) {
	    			  System.out.format("%-15s %-15s %-15s %-15s %s\n","Line1","Line2","State","City","pincode");
	    			  
	    			  
	    			  Iterator<Address> it=map.get(s2).iterator();
	    			//  System.out.println(it);
	    			  while(it.hasNext()) {
	    				  Address ad=it.next();
	    				 if(ad.getCity().equals(s2)) {
	    					 
	    					 System.out.println(ad);
	    				 }
	    				
	    			  }
	    		  }
	    			  else {
	    					 System.out.println("city is not found");
	    				 }
	    			  
	    		  }
	    		  else {
	    			  System.out.println("State is not found"+s1);
	    		  }
	    	  }
	    	  

	}
	      
	    	
	      

}

