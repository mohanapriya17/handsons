package first;

import java.util.Scanner;



public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
        Venue vs=new Venue();
        System.out.println("Enter the name");
       // vs.setName(name);
        String name=sc.nextLine();
        vs.setName(name);
        System.out.println("Enter the city");
        String city=sc.nextLine();
        vs.setCity(city);
        System.out.println("Venue details : "+"\n"+" name : "+vs.getName()+"\n" + " city: "+vs.getCity());

	}

}
