package collections1;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
      List list=new ArrayList();
      Scanner sc=new Scanner(System.in);
      int i=1;
      System.out.println("Enter the UserName"+i);
      String s1=sc.next();
      list.add(s1);
      while(true) {
    	  System.out.println("Do you want to continue?(y/n)");
    	  String s=sc.next();
    	  if(s.equals("y")) {
    		  i++;
    		  System.out.println("Enter the name of user"+i);
    		  String s3=sc.next();
    		  list.add(s3);
    	  }
    	  else {
    		  break;
    	  }
    	
    	  Iterator <String> it=list.iterator();
    	  System.out.println("The names are entered are");
    	  while(it.hasNext()) {
    		  System.out.println(it.next());
    		  
    	  }break;
      }
    	 
    	 
      }
	}


