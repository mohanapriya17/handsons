package collectionssolve;

public class emailComparator {

}
