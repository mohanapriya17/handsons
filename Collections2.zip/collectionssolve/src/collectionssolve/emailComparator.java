package collectionssolve;

import java.util.Comparator;

public class emailComparator implements Comparator {


	@Override
	public int compare(Object a, Object b) {
		User a1=(User)a;
		User b1=(User)b;
		return a1.getEmail().compareTo(b1.getEmail());
	}

}
