package six5;
import java.util.*;
public class Main {

	public static void main(String[] args) {
         Scanner sc=new Scanner(System.in);
       
         System.out.println("Enter Humpty's Sentence :");
         String s1=sc.nextLine();
         System.out.println("Humpty Says :"+s1);
         System.out.println("What Dumpty want to insert & where?");
         String s3=sc.nextLine();
         System.out.println("Enter Position :");
         int d=sc.nextInt();
         System.out.println(s1.substring(0, d-1) + s3 + s1.substring(d-2));
         
        
         
	}

}
