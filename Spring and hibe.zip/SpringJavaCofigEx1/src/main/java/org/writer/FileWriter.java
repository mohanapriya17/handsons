package org.writer;

import org.springframework.stereotype.Component;

@Component
public class FileWriter implements LogWriter {

	@Override
	public void write(String text) {
		System.out.println("Writing to the text file"+text);
	}

}
