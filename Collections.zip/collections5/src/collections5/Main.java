package collections5;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class Main {

	public static void main(String[] args) throws IOException {
		Set<String> numbers = new HashSet<>();
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the UserName");
		while(true) {
			numbers.add(br.readLine());
			
			System.out.println("Do you want to continue");
			String str=br.readLine();
			
			if(str.equals("y")) {
				
				System.out.println("Enter the userName");
			
			}
			else {
				break;
			}
			
		}
			System.out.println("The unique number of username"+numbers.size());
		
	}
     
    	 
     }
     
    
     
     
     
	



