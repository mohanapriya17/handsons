package second2;
import java.util.*;
public class Main {

	public static void main(String[] args) {
      Scanner sc=new Scanner(System.in);
      
      System.out.println("Enter the details:");
       Product prod=new Product();
       Product prod2=new Product();
       
       System.out.println("Enter the product code :");
       int code=sc.nextInt();
       prod.setProduct_code(code);
       sc.nextLine();
       System.out.println("Enter the Product name :");
       String name=sc.nextLine();
       prod.setProduct_name(name);
       sc.nextLine();
       System.out.println("Enter the price :");
       double prices=sc.nextDouble();
       prod.setPrice(prices);
       System.out.println("enter the stocks :");
       int stocks=sc.nextInt();
       prod.setStock(stocks);
       prod.setStatic_name("L&K SUPPLIERS");
       
       
       System.out.println("Enter the product code :");
       int code1=sc.nextInt();
       prod2.setProduct_code(code1);
       sc.nextLine();
       System.out.println("Enter the Product name :");
       String name1=sc.nextLine();
       prod2.setProduct_name(name1);
       sc.nextLine();
       System.out.println("Enter the price :");
       double prices1=sc.nextDouble();
       prod2.setPrice(prices1);
       System.out.println("enter the stocks :");
       int stocks1=sc.nextInt();
        prod2.setStock(stocks1);
        prod2.setStatic_name("L&K SUPPLIERS");
        prod.getDiscountedPrice();
        
       Product checkprice=new Product();
       checkprice.checkPrice(prod, prod2);
      // prod.getDiscountedPrice();
     //  prod2.getDiscountedPrice();
       
      // Product checkprice=new Product();
       //checkprice.checkPrice(prod, prod2);
     
     
       
          
	}

}
