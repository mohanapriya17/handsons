package java8features1;

import java.util.function.*;

public class java1 {

	public static void main(String[] args) {
		Function<String,Integer> fr=str->str.length();
		System.out.println("Hcl");
		System.out.println("Training");
	}

}
