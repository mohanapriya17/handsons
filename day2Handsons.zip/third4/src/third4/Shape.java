package third4;

public class Shape {
	double area;
	
	public void computeArea() {
		area=0;
	}
	public void menu() {
		System.out.println("Enter the Shape");
		System.out.println("1.Circle\n 2.Rectangle\n 3.Triangle");
		
	}

}
