package six4;
import java.util.*;
public class Main {

	public static void main(String[] args) {
		String str1, str2;
	       Scanner scan = new Scanner(System.in);
	       
	       System.out.print("Enter any String : ");
	       str1 = scan.nextLine();
	       
	       System.out.print("Dumpty Says  " +str1+"  ");
	       str2 = scan.nextLine();
	       
	       System.out.print("What Humpty Want To Remove? " );
	       str2 = scan.nextLine();
	       str1 = str1.replaceAll(str2, "");
	 
	           
	       System.out.println("\nDumpty's New Sentense : "+str1+" ");
       
       
	}

}

