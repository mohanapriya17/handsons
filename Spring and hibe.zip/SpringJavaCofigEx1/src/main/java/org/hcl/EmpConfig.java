package org.hcl;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class EmpConfig {
	@Bean(name = "e")
	public Emp getEmp() {
		Emp e=new Emp();
		e.setEno(1);
		e.setName("suresh");
		e.setAddress("chennai");
		return e;
	}
}
