package fifthday;

public class executiveStall implements stall {
	
	private String stallName;
	private Integer cost;
	private String ownerName;
	private Integer screen;
	
	protected executiveStall() {
		super();
	}

	protected executiveStall(String stallName, Integer cost, String ownerName, Integer screen) {
		super();
		this.stallName = stallName;
		this.cost = cost;
		this.ownerName = ownerName;
		this.screen = screen;
	}

	protected String getStallName() {
		return stallName;
	}

	protected void setStallName(String stallName) {
		this.stallName = stallName;
	}

	protected Integer getCost() {
		return cost;
	}

	protected void setCost(Integer cost) {
		this.cost = cost;
	}

	protected String getOwnerName() {
		return ownerName;
	}

	protected void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	protected Integer getScreen() {
		return screen;
	}

	protected void setScreen(Integer screen) {
		this.screen = screen;
	}

	public void display() {
		System.out.println("The Stall Type        :"+stallName);
		System.out.println("Cost      :"+cost+"Rs.");
		System.out.println("OWNER_NAME     "+ownerName);
		System.out.println("No of Tv Screen"+screen);
		
		
	
	}


}
