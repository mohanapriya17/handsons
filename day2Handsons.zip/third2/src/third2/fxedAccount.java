package third2;

public class fxedAccount extends savingAccount {
	private Integer locking_period;

	/**
	 * @param account_Number
	 * @param balance
	 * @param accountHolderName
	 * @param minimumBalance
	 * @param locking_period
	 */
	protected fxedAccount(String account_Number, double balance, String accountHolderName, double minimumBalance,
			Integer locking_period) {
		super(account_Number, balance, accountHolderName, minimumBalance);
		this.locking_period = locking_period;
	}

	/**
	 * 
	 */
	protected fxedAccount() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected Integer getLocking_period() {
		return locking_period;
	}

	protected void setLocking_period(Integer locking_period) {
		this.locking_period = locking_period;
	}
	
	void display() {
		System.out.println("Account Details");
		System.out.println("Account Number   :"+Account_Number);
		System.out.println("Balance Account    "+balance);
		System.out.println("Account Holder Name   "+accountHolderName);
		System.out.println("Minimum Balance    "+minimumBalance);
		System.out.println("locking period     "+locking_period);
	}
}