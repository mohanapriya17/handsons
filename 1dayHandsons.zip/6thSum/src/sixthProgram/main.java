package sixthProgram;
import java.util.*;
public class main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		ExtraType ex=new ExtraType();
		System.out.println("enter the extratype details ");
		String word=sc.nextLine();
		 String [] arr=word.split("#");
	        for(String a : arr)
	            System.out.print("");
	        
	
	        System.out.println("extratype details");
	        String name=arr[0];
	        ex.setName(name);
	       // String n=ex.getName();
	        System.out.println("Extratype: "+ex.getName());
	        String run=arr[1];
	        long run1=Long.parseLong(run);
	        ex.setRuns(run1);
	        //long b=ex.getRuns();
	        System.out.println("Runs: "+ex.getRuns());
	        //ex.display(n,b);
	        
	        
	       
	}
		

	}


