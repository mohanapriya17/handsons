package exceptionTopic;
import java.util.*;
import java.io.*;
public class Main {

	public static void main(String[] args) {
		try {
			
       Scanner sc=new Scanner(System.in);
		firstE fe=new firstE();
		 System.out.println("Enter the no of days");
			int day=sc.nextInt();
			fe.setDays(day);
			 System.out.println("Enter the no of days");
			 int n=sc.nextInt();
			 fe.setN(n);
			 if(day!=0) {
				 int d=day/n;
				 System.out.println("Cost of the item"+d);
			 }
			 else {
				 System.out.println(" ");
			 }
		
		
		}
		 
		
		catch(ArithmeticException ae) {
			System.out.println(ae);
			
			
			
       
	}
		}
}




