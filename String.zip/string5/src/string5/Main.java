package string5;
import java.util.*;
public class Main {

	public static void main(String[] args) {
      Scanner sc=new Scanner(System.in);
      
      System.out.println("Enter the name");
      String str = sc.nextLine();
      
      str = str.substring(0, 1).toUpperCase()  + str.substring(1);  
      while (str.contains(" ")) { 
         str = str .replaceFirst(" [a-z]",String.valueOf(Character.toUpperCase(str.charAt( str.indexOf(" ") + 1)))); 
      } 

      System.out.println("the camel"+str);
      
  }  
        

        
	}
	
	

