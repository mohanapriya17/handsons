package thirdday;

public class Account {
/**
	 * 
	 */
	
String accname;
/**
 * 
 */
protected Account() {
	super();
	// TODO Auto-generated constructor stub
}
String accno;
String Bankname;
protected String getAccname() {
	return accname;
}
protected void setAccname(String accname) {
	this.accname = accname;
}
protected String getAccno() {
	return accno;
}
protected void setAccno(String accno) {
	this.accno = accno;
}
protected String getBankname() {
	return Bankname;
}
protected void setBankname(String bankname) {
	Bankname = bankname;
}


protected void display() {
	
	
	
}
/**
 * @param accname
 * @param accno
 * @param bankname
 */
protected Account(String accname, String accno, String bankname) {
	super();
	this.accname = accname;
	this.accno = accno;
	Bankname = bankname;
}




}


