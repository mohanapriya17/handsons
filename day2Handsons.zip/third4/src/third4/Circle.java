package third4;

public class Circle extends Shape{
	private double radius;
	
	public void computeArea() {
		area=3.14*radius*radius;
		System.out.format("Circle:%.2f",area);
		
		
	}

	protected double getRadius() {
		return radius;
	}

	protected void setRadius(double radius) {
		this.radius = radius;
	}

	/**
	 * 
	 */
	protected Circle() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param radius
	 */
	protected Circle(double radius) {
		super();
		this.radius = radius;
	}

}
