package sixthday;
import java.util.*;
public class Main {

	public static void main(String[] args) {
       Scanner sc=new Scanner(System.in);
       System.out.println("Enter Humpty's Sentence :");
       String s1=sc.nextLine();
       System.out.println("Enter Dumpty's Sentence :");
       String s2=sc.nextLine();
       s1=s1+"."+s2;
       System.out.println("Cocantenated String   :"+s1);
       
	}

}
