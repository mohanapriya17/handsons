package collectionssolve5;

import java.io.*;
import java.util.*;

public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		List<User> list=new ArrayList<>();
       BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
       System.out.println("Enter the number of user details");
       int n=Integer.parseInt(br.readLine());
       if(n>0) {
    	   for(int i=1;i<=n;i++) {
    		   System.out.println("Enter the user "+ i+ " detail");
    		   String details=br.readLine();
    		   String[]b=details.split(",");
    		   list.add(new User(b[0],b[1],b[2],b[3]));
    		   
    	   }
    	  System.out.println("Sort by");
    	  System.out.println("\n1.Name \n2.Email");
    	  
    	  int ch=Integer.parseInt(br.readLine());
    	  switch(ch) {
    	  case 1: 
    		  Collections.sort(list, new NameComparator());
    		  break;
    	  case 2:
    		  Collections.sort(list, new EmailComparator());
    		  break;
    	  default:
    		  System.out.println("Invalid output");
    		  
    		  
    	  }
    	  System.out.format("%-15s %-15s %-15s %s" ,"Name","email","Username","Password");
    	  System.out.println("");
    	  for(User user :list) {
    		  System.out.format("%-15s %-15s %-15s %s" ,user.getName(),user.getEmail(),user.getUsername(),user.getPassword());
    	  }
       }
       
	}

}
