package fourthday;

public class Circle extends Shape{
double radius;
public Double CalculatePerimeter() {
	double area=2*3.14*radius;
	
	
	return area;
	
}
protected double getRadius() {
	return radius;
}
protected void setRadius(double radius) {
	this.radius = radius;
}
/**
 * @param radius
 */
protected Circle(double radius) {
	super();
	this.radius = radius;
}
/**
 * 
 */
protected Circle() {
	super();
	// TODO Auto-generated constructor stub
}
public void menu() {
	System.out.println("\nLIST OF SHAPES");
	System.out.println("\n1.Circle\n 2.Rectangle\n 3.Triangle");
	
}


}
