package adrresss;
import java.util.*;
public class address {
	String name;
	String city;



	public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        address vs=new address();
        System.out.println("Enter the name");
        vs.name=sc.nextLine();
        System.out.println("Enter the city");
        vs.city=sc.nextLine();
        System.out.println("Venue details:"+"name"+vs.name+"  city "+vs.city);
        
	}

}
