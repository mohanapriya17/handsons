package thirdday;

public class currentAccount extends Account{
	/**
	 * 
	 */
	

	protected String getTIN_number() {
		return TIN_number;
	}

	/**
	 * 
	 */
	protected currentAccount() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void setTIN_number(String tIN_number) {
		TIN_number = tIN_number;
	}

	
	protected currentAccount(String accname, String accno, String bankname, String tIN_number) {
		super(accname, accno, bankname);
		TIN_number = tIN_number;
	}

	String TIN_number;


protected void display() {
	System.out.println("Account Name    "+accname);
	System.out.println("Account Number    "+accno);
	System.out.println("Bankname        "+Bankname);
	System.out.println("TIN_NUMBER       "+TIN_number);
	
}
public void display1() {
	super.display();
	System.out.println("TIN_NUMBER       "+TIN_number);
	
	
}
}
