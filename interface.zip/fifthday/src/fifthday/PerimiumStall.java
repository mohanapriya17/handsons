package fifthday;

public class PerimiumStall implements stall {
	private String stallName;
	private Integer cost;
	private String ownerName;
	private Integer projector;
	

	/**
	 * 
	 */
	protected PerimiumStall() {
		super();
	}


	
	protected PerimiumStall(String stallName, Integer cost, String ownerName, Integer projector) {
		super();
		this.stallName = stallName;
		this.cost = cost;
		this.ownerName = ownerName;
		this.projector = projector;
	}


	protected String getStallName() {
		return stallName;
	}


	protected void setStallName(String stallName) {
		this.stallName = stallName;
	}


	protected Integer getCost() {
		return cost;
	}


	protected void setCost(Integer cost) {
		this.cost = cost;
	}


	protected String getOwnerName() {
		return ownerName;
	}


	protected void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}


	protected Integer getProjector() {
		return projector;
	}


	protected void setProjector(Integer projector) {
		this.projector = projector;
	}


	public void display() {
		System.out.println("The Stall Type        :"+stallName);
		System.out.println("Cost      :"+cost+"Rs.");
		System.out.println("OWNER_NAME     "+ownerName);
		System.out.println("No of projector "+projector);
		
	
	}


}
