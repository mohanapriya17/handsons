package third4;

public class Triangle extends Shape{
	protected double getBase() {
		return base;
	}

	protected void setBase(double base) {
		this.base = base;
	}

	protected double getHeight() {
		return height;
	}

	protected void setHeight(double height) {
		this.height = height;
	}

	/**
	 * 
	 */
	protected Triangle() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param base
	 * @param height
	 */
	protected Triangle(double base, double height) {
		super();
		this.base = base;
		this.height = height;
	}

	double base,height;
	
	public void computeArea() {
		area=0.5*base*height;
		System.out.format("Triangle%.2f",area);
	}

}
