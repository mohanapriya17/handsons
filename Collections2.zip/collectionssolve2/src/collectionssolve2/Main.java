package collectionssolve2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		List<Stall> list=new ArrayList<>();
      BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
      System.out.println("Enter the number of stall details");
      int n=Integer.parseInt(br.readLine());
      if(n>0) {
    	  for(int i=0;i<n;i++) {
    		  System.out.println("Enter the number of stall details  :");
    		  String s=br.readLine();
    		  String[]a=s.split(",");
    		  list.add(new Stall(a[0],a[1],a[2],a[3]));
    		  
    			
    		  
    	  }
    	  System.out.format("%-15s %-20s %-15s %s","name","detail","type","ownername");
    	  System.out.println();
    	  Iterator <Stall>it=list.iterator();
    	  while(it.hasNext()) {
    		 Stall s= it.next();
    		 if(s.getName().startsWith("test"))
    			 it.remove();
    		  System.out.println(s);
    	  }
      }
      
      
	}

}
