package collections3;
import java.util.*;
public class Main {

	public static void main(String[] args) {
        List list=new ArrayList();
        int n;
        String search;
        Scanner sc=new Scanner(System.in);
        
        System.out.println("Enter the no.of halls");
        n=sc.nextInt();
        for(int i=0;i<n;i++) {
        	sc.hasNextLine();
        	System.out.println("Enter the hall name");
        	list.add(sc.nextLine());
        	
        }
        sc.hasNextLine();
        System.out.println("Enter the hall name to be search");
        sc.nextLine();
        search=sc.nextLine();
        if(list.contains(search)==true) 
        	System.out.println(search+"   is found at position of  "+list.indexOf(search));
        	
        else
        	System.out.println(search+"   Hall is not Found");
	}

}
