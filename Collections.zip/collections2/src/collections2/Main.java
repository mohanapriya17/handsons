package collections2;
import java.util.*;
public class Main {

	public static void main(String[] args) {
List  list=new ArrayList();

Scanner sc=new Scanner(System.in);
int i=1;
System.out.println("Enter the item details "+i);

do {
	
i++;
System.out.println("Name");
String name=sc.nextLine();
sc.nextLine();
System.out.println("deposit");
double deposit=sc.nextDouble();
sc.nextLine();
System.out.println("CostperDay");
double costperday=sc.nextDouble();
itemType it= new itemType(name, deposit, costperday);
list.add(it);

	  System.out.println("Do you want to continue?(y/n)");
	  String s3=sc.next();
	  if(s3.equals("y")) {
		 
		  System.out.println("Enter the name of user"+i);
		  
	  }else {
		  break;
	  }
	  }while(true);
	  
	Iterator <itemType> it1 =list.iterator();
	System.out.println("The entered names are");
while(it1.hasNext()) {
		itemType item=it1.next();
		System.out.println(it1);
	}
}
}



	



	


	


