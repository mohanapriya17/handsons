package second2;



public class Product {
int product_code;
String product_name;
/**
 * 
 */
public Product() {
	super();
	// TODO Auto-generated constructor stub
}
/**
 * @param product_code
 * @param product_name
 * @param price
 * @param stock
 * @param static_name
 */
public Product(int product_code, String product_name, double price, int stock, String static_name) {
	super();
	this.product_code = product_code;
	this.product_name = product_name;
	this.price = price;
	this.stock = stock;
	this.static_name = static_name;
}
double price;
int stock;
String static_name;
public int getProduct_code() {
	return product_code;
}
public void setProduct_code(int product_code) {
	this.product_code = product_code;
}
public String getProduct_name() {
	return product_name;
}
public void setProduct_name(String product_name) {
	this.product_name = product_name;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
public int getStock() {
	return stock;
}
public void setStock(int stock) {
	this.stock = stock;
}
public String getStatic_name() {
	return static_name;
}
public void setStatic_name(String static_name) {
	this.static_name = static_name;
}

/*void display() {
	System.out.println("product code  :"+product_code);
	System.out.println("product Name  : "+product_name);
	System.out.println("price :  "+price);
	System.out.println("Stocks :"+stock);
}*/

void checkPrice(Product prod,Product prod2) {
	if(prod.getPrice()<prod2.getPrice()) {
		//System.out.println("product code  :"+prod.getProduct_code());
	//	System.out.println("product Name  : "+prod.getProduct_name());
	//	System.out.println("price :  "+prod.getPrice());
	//	System.out.println("Stocks :"+prod.getStock());
		System.out.println(prod.getStatic_name());
		prod.getDiscountedPrice();
		System.out.println(prod.getProduct_name()+"  is costly than "+prod2.getProduct_name());
	}
	else {
	//	System.out.println("product code  :"+prod2.getProduct_code());
	//	System.out.println("product Name  : "+prod2.getProduct_name());
	//	System.out.println("price :  "+prod2.getPrice());
	//	System.out.println("Stocks :"+prod2.getStock());
		System.out.println(prod.getStatic_name());
		prod2.getDiscountedPrice();
		System.out.println(prod2.getProduct_name()+"  is cheaper than  "+prod.getProduct_name());
		//prod2.getDiscountedPrice();
		
	}
	
}
void getDiscountedPrice() {
if(price<=80000 && price>=60000) {
	double discount=30;//30 means 30%
	
	double prices= (discount*price)/100;
	
	System.out.println("product code   "+product_code);
	System.out.println("product Name  "+product_name);
	System.out.println("price   :"+price);
	System.out.println("Stocks   :"+stock);
	System.out.println("discount price   "+prices);
	
	//System.out.println();
}
else if(price<=60000 && price>=50000) {
	double discount2=20;//20 means 20%
	double discount21=100-discount2;
	double prices2= (discount2*price)/100;
	//double prices12= prices-6500;
	System.out.println("product code    "+product_code);
	System.out.println("product Name   "+product_name);
	System.out.println("price    :"+price);
	System.out.println("Stocks    :"+stock);
	System.out.println("discount price    "+prices2);
}
else if(price<=50000 && price>50000) {
	double discount3=10;//10 means 30%
	double discount31=100-discount3;
	double prices3= (discount3*price)/100;
	//double prices13= prices3-6500;
	System.out.println("product code   :"+product_code);
	System.out.println("product Name   :"+product_name);
	System.out.println("price    :"+price);
	System.out.println("Stocks    :"+stock);
	System.out.println("discount price   :"+prices3);
}
else if(price<=50000) {
	double discount4=5;//5 means 30%
	double discount41=100-discount4;
	double prices4= (discount4*price)/100;
	//double prices13= prices3-6500;
	System.out.println("product code   :"+product_code);
	System.out.println("product Name    :"+product_name);
	System.out.println("price     :"+price);
	System.out.println("Stocks     :"+stock);
	System.out.println("discount price   :"+prices4);
	
}


}
}
