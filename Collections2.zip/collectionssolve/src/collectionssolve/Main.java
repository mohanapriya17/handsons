package collectionssolve;
import java.io.*;
import java.util.*;
public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
      BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
      List<User> list=new ArrayList<>();
      System.out.println("Enter the number of user details  ");
      int s=Integer.parseInt(br.readLine());
      if(s>0) {
    	  for(int i=1;i<=s;i++) {
    		  System.out.println("Enter the user"+i+" detail");
    		  String sr=br.readLine();
    		  String[]str=sr.split(",");
    		  list.add(new User(str[0],str[1],str[2],str[3]));
    		  
    	  }
    	  System.out.println("Search by");
    	  System.out.println("\n1.Name \n2.Email");
    	  int ch=Integer.parseInt(br.readLine());
    	  switch(ch) {
    	  case 1: 
    		  Collections.sort(list);
    		  System.out.println("Enter Name");
    		  int a=Collections.binarySearch(list,new User(br.readLine(),null,null,null), null);
    		  if(a>0) {
    			  System.out.format("%-15s %-15s %-15s %s","Name","email","UserName","Password");
    			  System.out.println("");
    			  User be=list.get(a);
    			  System.out.println(be);
    		  }
    		  else {
    			  break;
    		  }
    		  break;
    	  case 2:
    		  Comparator c=new emailComparator();
    		  list.sort(c);
    		  System.out.println("Enter Email");
    		  int a1=Collections.binarySearch(list,new User(null,br.readLine(),null,null), null);
    		  if(a1>0) {
    			  System.out.format("%-15s %-15s %-15s %s","Name","email","UserName","Password");
    			  System.out.println("");
    			  User be2=list.get(a1);
    			  System.out.println(be2);
    		  
    		  
    	  }
    		  else {
    			  break;
    		  }
    		  break;
      }
      
	}

}
}