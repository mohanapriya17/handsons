package player;
import java.util.*;
public class main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the player name");
		player pl=new player();
		String name =sc.nextLine();
		pl.setName(name);
		
		System.out.println("Enter the country name");
		String country=sc.nextLine();
		pl.setCity(country);
		
		System.out.println("enter the skill");
		String skill=sc.nextLine();
		pl.setSkill(skill);
		
		System.out.println("player details:"+"\n" + "Name: "+pl.getName()+"\n"+"Country: "+pl.getCity()+"\n"+"Skill: "+pl.getSkill());
		
		

	}

}
