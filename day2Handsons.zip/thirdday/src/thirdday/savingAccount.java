package thirdday;

public class savingAccount extends Account {
	String org_Name;

	
	protected savingAccount(String accname, String accno, String bankname, String org_Name) {
		super(accname, accno, bankname);
		this.org_Name = org_Name;
	}

	protected String getOrg_Name() {
		return org_Name;
	}

	protected void setOrg_Name(String org_Name) {
		this.org_Name = org_Name;
	}

	/**
	 * 
	 */
	protected savingAccount() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	void choice() {
		System.out.println("Choose Account Type");
		System.out.println(" ");
		System.out.println("Savings Account");
		System.out.println("Current Account");
	}
	
	protected void display() {
		System.out.println("Account Name      "+accname);
		System.out.println("Account Number     "+accno);
		System.out.println("Bankname           "+Bankname);
		//System.out.println("Organization Name    "+org_Name);
	}
	public void display1() {
		super.display();
		System.out.println("Organiation Name       "+org_Name);
	

}
}
