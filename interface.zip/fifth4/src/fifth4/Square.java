package fifth4;

public class Square implements PolygonInterface {
	double side;
	
	/**
	 * 
	 */
	protected Square() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param side
	 */
	protected Square(double side) {
		super();
		this.side = side;
	}
	protected double getSide() {
		return side;
	}
	protected void setSide(double side) {
		this.side = side;
	}
	public void calciPeri() {
		double p=4*side;
		System.out.println("Perimeter of square"+p);
	}
	public void caluArea() {
		double p1=side*side;
		System.out.println("area of square"+p1);
		
	}

}
