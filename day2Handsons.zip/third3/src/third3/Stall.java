package third3;

public class Stall {
	String name;
	String detail;
	String ownername;
	protected String getName() {
		return name;
	}
	protected void setName(String name) {
		this.name = name;
	}
	protected String getDetail() {
		return detail;
	}
	protected void setDetail(String detail) {
		this.detail = detail;
	}
	protected String getOwnername() {
		return ownername;
	}
	protected void setOwnername(String ownername) {
		this.ownername = ownername;
	}
	/**
	 * 
	 */
	/**
	 * @param name
	 * @param detail
	 * @param ownername
	 */
	protected Stall(String name, String detail, String ownername) {
		super();
		this.name = name;
		this.detail = detail;
		this.ownername = ownername;
	}
	/**
	 * 
	 */
	protected Stall() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Double computeCost(String stallType,Integer squareFeet) {
		if(stallType.equals("platinum")) {
			double sqft =squareFeet*200;
			return sqft;
			
		}
		else if(stallType.equals("gold")) {
			double sqft1=squareFeet*100;
			return sqft1;
		
		}
		else {
			double sqft1=squareFeet*150;
			return sqft1;
		}
		
	
		
	}


	public Double computeCost(String stallType,Integer squareFeet,Integer NumberofTv) {
		double sqft=0;
		double tot=0;
		if(stallType.equals("platinum")) {
			 sqft =squareFeet*200;
		
		}
		else if(stallType.equals("gold")) {
			 sqft=squareFeet*100;
		}
		else {
			 sqft=squareFeet*150;
			
		
		}
	
		tot=sqft+(NumberofTv*10000);
		return tot;
		
	}
	

}
