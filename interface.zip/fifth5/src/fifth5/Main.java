package fifth5;
import java.util.*;
public class Main {

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		CarService car=new CarService();
		System.out.println("Enter your Car Number");
		int num=sc.nextInt();
		System.out.println("How many years old car do you have");
		int years=sc.nextInt();
		System.out.println("Car Brand");
		sc.nextLine();
		String brand =sc.nextLine();
		car.sum(num);
		car.year(years);
		car.brand(brand);
		
	}

}
