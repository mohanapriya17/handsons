package org.writer;

public interface LogWriter {
	void write(String text);
}
