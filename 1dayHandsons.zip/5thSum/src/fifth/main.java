package fifth;
import java.util.*;
public class main {

	public static void main(String[] args) {
      Scanner sc=new Scanner(System.in);
     // Venue vs=new Venue();
      Venue vs=new Venue();
      System.out.println("enter the venue name: ");
      String name=sc.nextLine();
      vs.setName(name);
      System.out.println("enter the city name: ");
      String city=sc.nextLine();
      vs.setCity(city);
      System.out.println("Venue details");
      System.out.println("venue name : "+vs.getName());
      System.out.println("city name : "+vs.getCity());
      vs.menu();
      System.out.println("enter the choice");
    //  int ch=sc.nextInt();
      int n=0;
      while(n<3) {
    	  int ch=sc.nextInt();
    	  switch(ch) {
    	  case 1:
    		  System.out.println("enter venue name: ");
    		  sc.nextLine();
    		  String Name1=sc.nextLine();
    		  vs.setName(Name1);
    		
              System.out.println("venue details");
    		    System.out.println("venue name: "+vs.getName());
    		  System.out.println("venue city: "+vs.getCity());
    		  vs.menu();
    		
    		  break;
    	  case 2:
    		  System.out.println("enter city name: ");
    		  sc.nextLine();
    		  String city2=sc.nextLine();
    		  vs.setCity(city2);
    		 
    		  System.out.println("venue details");
    		  System.out.println("venue name: "+vs.getName());
    		  System.out.println("venue city: "+vs.getCity());
    		  vs.menu();
    		  break;
    	  case 3:
    		  System.out.println("venue details");
    		  System.out.println("venue name: "+vs.getName());
    		  System.out.println("venue city: "+vs.getCity());
    		  //vs.menu();
    		  break;
    	  }
    		  
    		  n++;
    	  }
      }
      
      
      
	}


