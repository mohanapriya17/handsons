package collectionssolve6;

import java.io.*;
import java.util.*;

public class Main {

	public static void main(String[] args) throws IOException {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        List<Integer> showlist=new ArrayList<>();
        List< List<Integer>> daylist=new ArrayList<>();
        System.out.println("Enter the count of booked tickets:  ");
        for(int i=1;i<=5;i++) {
        	System.out.println("On Day "+i);
        	String str=br.readLine();
        	String [] st=str.split(",");
        	showlist.add(100-Integer.parseInt(st[0]));
        	showlist.add(100-Integer.parseInt(st[1]));
        	showlist.add(100-Integer.parseInt(st[2]));
        	showlist.add(100-Integer.parseInt(st[3]));
        	
        }
        
        int day=0;
        for(int i=1;i<=5;i++) {
        	daylist.add(showlist.subList(day, day+4));
        	day=day+4;
        	System.out.println(showlist);
        	
        }
        do {
        	System.out.println("Enter the day to know its remaining ticket count:  ");
        	int count=Integer.parseInt(br.readLine());
        	System.out.println("Remaining tickets:["+daylist.get(count-1));
        	System.out.println("Do you want to continue?(y/n)");
        	String s=br.readLine();
        	if(s.equals("n")) {
        		break;
        		
        	}
        	
        	
        }while(true);
	}

}
