package org.writer;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext context=new AnnotationConfigApplicationContext(LoggerConfig.class);
		Logging logging=context.getBean(Logging.class,"logging");
		logging.writeToConsole("hello");
		logging.writeToFile("hello");
		//((AnnotationConfigApplicationContext)context).close();
	}

}
