package org.hcl2;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class index
 */
@WebServlet("/index")
public class index extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public index() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter printwriter=response.getWriter();
		printwriter.write("<html>");
		printwriter.write("<head>");
		printwriter.write("<body>");
		printwriter.write("<h1 style=\"text-align:center; color:black;\">USER DETAILS</h1>");
		printwriter.write("<div Style=\"text-align:center;\">");
		printwriter.write("<form action=\"./Display\"method=\"get\">");
		printwriter.write("Name<input type=\"\text\"name=\"name\"><br>");
		printwriter.write("PhoneNumber<input type=\"\text\" name=\"phonenumber\"><br>");
		printwriter.write("email<input type=\"\text\"name=\"email\"><br>");
		printwriter.write("city<input type=\"\text\"name=\"city\"><br>");
		printwriter.write("<input type=\"Submit\"name=\"Submit\"><br>");
		printwriter.write("</form");
		printwriter.write("<body>");
		printwriter.write("</head>");
		printwriter.write("</html>");
		printwriter.close();
		
		
		
		
		
	}

}
