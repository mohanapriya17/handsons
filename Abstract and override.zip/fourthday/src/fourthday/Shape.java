package fourthday;

public abstract class Shape {
	  
	public abstract Double CalculatePerimeter();
	
	
	

}
