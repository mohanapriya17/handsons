import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
       try {
    	   int a[]=new int[10];
    	   Scanner sc=new Scanner(System.in);
    	   System.out.println("Enter any 10 values");
    	   for(int i=0;i<a.length;i++) {
    		   a[i]=sc.nextInt();
    	   }
    	   for(int j=10,k=0;j>=0;j--,k++) {
    		   int res=a[k]/j;
    		   System.out.println("Output after handling the exception :"+res);
    	   }
       }
       catch(Exception e) {
    	   System.out.println(e);
       }
	}

}
