package org.hcl3;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class index
 */
@WebServlet("/index")
public class index extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public index() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter printwriter=response.getWriter();
		printwriter.write("<html>");
		printwriter.write("<head>");
		printwriter.write("<body>");
		printwriter.write("<h1 style=\"text-align:center; color:black;\">USER DETAILS</h1>");
		printwriter.write("<div Style=\"text-align:center;\">");
		printwriter.write("<table>");
		printwriter.write("<form action=\"./Validate\"method=\"get\">");
		printwriter.write("<tr><td>Name<input type=\"text\"name=\"name\"></tr></td><br>");
		printwriter.write("<tr><td>HallName<input type=\"text\" name=\"hallname\"></tr></td><br>");
		printwriter.write("<tr><td>EventType</td><td><input type=\"radio\" value='Exhibition'name=\"type\">Exhibition<br>"+
		"<input type=\"radio\" value='Stage_Event'name=\"type\">Stage_Event<br></td></tr>");	
		printwriter.write("<tr><td>details</td><td><input type=\"text\"name=\"detail\"></tr></td><br>");
		printwriter.write("<tr><td>Owner</td><td><input type=\"text\"name=\"owner\"></tr></td><br>");
		printwriter.write("<tr><td>StartDate</td><td><input type=\"text\"name=\"StartDate\"></tr></td><br>");
		printwriter.write("<tr><td>EndDate</td><td><input type=\"text\"name=\"EndDate\"></tr></td><br>");
		printwriter.write("<tr><td><input type=\"Submit\"name=\"Submit\"></tr></td><br>");
		printwriter.write("</form>");
		printwriter.write("</table>");
		printwriter.write("</body>");
		printwriter.write("</head>");
		printwriter.write("</html>");
		
		
	}
	
	protected void dopost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter printwriter=response.getWriter();

		printwriter.write("<html>");
		printwriter.write("<head>");
		printwriter.write("<body>");
		printwriter.write("<h1 style=\"text-align:center; color:black;\">Event Creation</h1>");
		printwriter.write("<div Style=\"text-align:center;\">");
		printwriter.write("<table>");
		printwriter.write("<form action=\"./Validate\"method=\"get\">");
		printwriter.write("<tr><td>Name<input type=\"text\"name=\"name\"></tr></td><br>");
		printwriter.write("<tr><td>HallName<input type=\"text\" name=\"hallname\"></tr></td><br>");
		printwriter.write("<tr><td>EventType</td><td><input type=\"radio\" value='Exhibition'name=\"type\">Exhibition<br>"+
		"<input type=\"radio\" value='Stage_Event'name=\"type\">Stage_Event<br></td></tr>");	
		printwriter.write("<tr><td>details</td><td><input type=\"text\"name=\"detail\"></tr></td><br>");
		printwriter.write("<tr><td>Owner</td><td><input type=\"text\"name=\"owner\"></tr></td><br>");
		printwriter.write("<tr><td>StartDate</td><td><input type=\"text\"name=\"StartDate\"></tr></td><br>");
		printwriter.write("<tr><td>EndDate</td><td><input type=\"text\"name=\"EndDate\"></tr></td><br>");
		printwriter.write("<tr><td><input type=\"Submit\"name=\"Submit\"></tr></td><br>");
		printwriter.write("</form>");
		printwriter.write("</table>");
		printwriter.write("</body>");
		printwriter.write("</head>");
		printwriter.write("</html>");
		

}
}
