package fourthday;
import java.io.IOException;
import java.util.*;
public class Main {
	

	public static void main(String[] args) throws IOException {
		Scanner sc=new Scanner(System.in);
	System.out.println("");
		Circle cc= new Circle();
		Rectangle rect=new Rectangle();
		Square sq=new Square();
		int n=0;
		while(n<3) {
			//int ch1=sc.nextInt();
	       cc.menu();
	       System.out.println("Enter the Choice");
	       int ch1=sc.nextInt();
	        switch(ch1) {
	        
	        case 1:
	            System.out.println("\nenter the radius  ");
	            double rad=sc.nextDouble();
	            cc.setRadius(rad);
	            System.out.format("\nThe perimeter of the circle %.2f",cc.CalculatePerimeter());
	            sc.nextLine();
	            //cc.menu();
	            break;
	        case 2:
	            System.out.println("\nenter the length of the rectangle   ");
	            float len=sc.nextFloat();
	            rect.setLength(len);
	            System.out.println("\nenter the breadth of the rectangle   ");
	            float bread=sc.nextFloat();
	            rect.setBreadth(bread);
	            System.out.format("\nThe perimeter of the rectangle%.2f",rect.CalculatePerimeter());
	            sc.nextLine();
	            //cc.menu();
	            break;
	            
	        case 3:
	            System.out.println("\nenter the side of the square  ");
	            float sqt=sc.nextFloat();
	            sq.setSide(sqt);
	            
	            System.out.format("\nThe perimeter of the square%.2f",cc.CalculatePerimeter());
	            //cc.menu();
	            break;
	            
	            
	           		
		}
	        n++;
		
		}
		
		
		
			
		
       
	}

}
