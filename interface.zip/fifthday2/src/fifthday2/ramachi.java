package fifthday2;

public class ramachi implements Fort {
	int distance;
	
	
	/**
	 * 
	 */
	protected ramachi() {
		super();
		// TODO Auto-generated constructor stub
	}


	/**
	 * @param distance
	 */
	protected ramachi(int distance) {
		super();
		this.distance = distance;
	}


	protected int getDistance() {
		return distance;
	}


	protected void setDistance(int distance) {
		this.distance = distance;
	}
 public void menu() {
	 System.out.println("What you want to visit");
	 System.out.println("Ramahi");
	 System.out.println("Shivagh");
	 System.out.println("Murud");
	 
 }

	public void distance() {
		System.out.println("You are going to visit ramachi");
		System.out.println("the distance is 55Km");
	}

}
