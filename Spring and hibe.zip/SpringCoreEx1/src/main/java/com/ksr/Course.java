package com.ksr;

public class Course {
	private int cid;
	private String cname;
	private double duration;
	public Course() {
		// TODO Auto-generated constructor stub
	}
	public Course(int cid, String cname, double duration) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.duration = duration;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public double getDuration() {
		return duration;
	}
	public void setDuration(double duration) {
		this.duration = duration;
	}
	
}
