package collectionssolve5;

import java.util.Comparator;

public class NameComparator implements Comparator<User> {

	@Override
	public int compare(User n1, User n2) {
		return n1.getName().compareTo(n2.getName());
	}


	}


