package collectionssolve3;
import java.util.Comparator;
public class Hall implements Comparable{
	private String name,contactNumber,ownerName;
	private double costperday;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public double getCostperday() {
		return costperday;
	}
	public void setCostperday(double costperday) {
		this.costperday = costperday;
	}
	/**
	 * 
	 */
	public Hall() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param name
	 * @param contactNumber
	 * @param ownerName
	 * @param costperday
	 */
	public Hall(String name, String contactNumber, String ownerName, double costperday) {
		super();
		this.name = name;
		this.contactNumber = contactNumber;
		this.ownerName = ownerName;
		this.costperday = costperday;
		
	}
	
	@Override
	public String toString() {
		System.out.format("%-15s%-15s%-15s%-15s",name,contactNumber,ownerName,costperday);
		System.out.println("");
		return "";
	}
	@Override
	public int compareTo(Object obj) {
		Hall h=(Hall)obj;
		if(h.getCostperday()<costperday) {
			return 1;}
		else if(h.getCostperday()>costperday) {
			return -1;}
		else {
			
		return 0;}
	}
	
	}
	
	


