package fifth3;

public class HDFC implements MutualFund {

public void duration() {
	 System.out.println("Enter the tenure of SIP");
	
}
public void amount() {
	 System.out.println("Enter the Amount of Interest");
	
	 
}
}
