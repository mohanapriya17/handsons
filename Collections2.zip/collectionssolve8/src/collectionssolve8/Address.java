package collectionssolve8;

public class Address {
	private String addressLine1,addressline2,state,city;
	private Integer pincode;
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressline2() {
		return addressline2;
	}
	public void setAddressline2(String addressline2) {
		this.addressline2 = addressline2;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Integer getPincode() {
		return pincode;
	}
	public void setPincode(Integer pincode) {
		this.pincode = pincode;
	}
	/**
	 * @param addressLine1
	 * @param addressline2
	 * @param state
	 * @param city
	 * @param pincode
	 */
	public Address(String addressLine1, String addressline2, String state, String city, Integer pincode) {
		super();
		this.addressLine1 = addressLine1;
		this.addressline2 = addressline2;
		this.state = state;
		this.city = city;
		this.pincode = pincode;
	}
	/**
	 * 
	 */
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		//System.out.println("");
		System.out.format("%-15s %-15s %-15s %-15s %s\n", addressLine1,addressline2, state,city,pincode );
		return "";
	}

}
