package org.hcl3;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Validate
 */
@WebServlet("/Validate")
public class Validate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Validate() {
        super();
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter printwriter=response.getWriter();
		String eventname=request.getParameter("name");
		String hallname=request.getParameter("hallname");
		String eventtype=request.getParameter("eventtype");
		String details=request.getParameter("detail");
		String owner=request.getParameter("owner");
		String startdate=request.getParameter("StartDate");
		String enddate=request.getParameter("EndDate");
		if(eventname=="" || enddate=="" || eventtype=="" ||details=="" || owner==""||startdate==""||hallname=="") {
			RequestDispatcher rd=request.getRequestDispatcher("./index");
			if(eventname.isEmpty()) {
				printwriter.write("<h3>Event</h3>");
			}
			if(hallname=="") {
				printwriter.write("<h3>hallname is required</h3>");
			}
			if(eventtype=="") {
				printwriter.write("<h3>eventtype is required</h3>");
			}
			if(details=="") {
				printwriter.write("<h3>details is required</h3>");
			}
			if(owner=="") {
				printwriter.write("<h3>owner is required</h3>");
			}
			if(startdate=="") {
				printwriter.write("<h3>startdate is required</h3>");
			}
			if(enddate=="") {
				printwriter.write("<h3>enddateis required</h3>");
			}
			
			
			
			rd.include(request, response);
		}
			else {
				printwriter.write("<html>");
				printwriter.write("<head>");
				printwriter.write("<body>");
				printwriter.write("<h1 style=\"text-align:center; color:black;\">Event created successfully</h1>");
				printwriter.write("<h3>EventDetails</h3>");
				printwriter.write("<table id='event'border='1'>");
				printwriter.write("<tr><td>EventName</td><td>"+eventname+"</td></tr>");
				printwriter.write("<tr><td> hallname</td><td>"+ hallname+"</td></tr>");
				printwriter.write("<tr><td>eventtype</td><td>"+eventtype+"</td></tr>");
				printwriter.write("<tr><td>details</td><td>"+details+"</td></tr>");
				printwriter.write("<tr><td>owner</td><td>"+owner+"</td></tr>");
				printwriter.write("<tr><td>startdate</td><td>"+startdate+"</td></tr>");
				printwriter.write("<tr><td>enddate</td><td>"+enddate+"</td></tr>");
				
				
				
				
				
				
				
			}
			
		}
		
	
	
	}
	


