package fifthday2;

interface Fort{
	void distance();
}

public class firstClass {

}
