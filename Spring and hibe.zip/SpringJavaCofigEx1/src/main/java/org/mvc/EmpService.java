package org.mvc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmpService {
	EmpDao dao;
	public EmpService() {
		// TODO Auto-generated constructor stub
	}
	public EmpDao getDao() {
		return dao;
	}
	@Autowired
	public void setDao(EmpDao dao) {
		this.dao = dao;
	}
	public void insert()
	{
		dao.insertData();
	}
	
}
