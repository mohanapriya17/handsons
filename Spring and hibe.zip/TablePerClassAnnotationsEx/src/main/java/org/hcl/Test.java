package org.hcl;

import org.hcl.entities.Bowler;
import org.hcl.entities.Person;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {

	public static void main(String[] args) {
		Configuration configuration=new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory factory=configuration.buildSessionFactory();
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		Person person=new Person();
		person.setFirstName("ravi");
		person.setLastName("shastri");
		session.persist(person);
		Bowler bowler=new Bowler();
		bowler.setFirstName("boomra");
		bowler.setLastName("b");
		bowler.setBowlingHand("right");
		bowler.setWickets(5);
		session.persist(bowler);
		transaction.commit();
		session.close();
	}

}
