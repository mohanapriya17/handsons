package fourth2;

public class Exhibition extends Event{
Integer NoofStall;

protected Integer getNoofStall() {
	return NoofStall;
}

protected void setNoofStall(Integer noofStall) {
	NoofStall = noofStall;
}


/**
 * @param name
 * @param details
 * @param ownerName
 */
protected Exhibition(String name, String details, String ownerName) {
	super(name, details, ownerName);
	// TODO Auto-generated constructor stub
}

protected Exhibition() {
	super();
}
public Double Projectedrevenue(Integer NoofStall) {
	double revenue=10000;
	double prevenue=NoofStall*10000;
	
	
	
	return prevenue;
	
}
}
