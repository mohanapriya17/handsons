package collections9;

import java.util.ArrayList;

public class UserBO extends ArrayList {
	static UserBO u=new UserBO();
	
	void remove(int a,int b) {
		removeRange(a,b);
	}
	static UserBO getList(){
		u.add(new User("mohan Raja" ,"9874563210" ," mohan",  "mohan@abc.in"));
		u.add(new User("arjun Ravi","4324237" ,"arjun","arjun@abc.in"));
		u.add(new User("Ram ganesh","9874587457","Ram","ramg@abc.in"));
		
		return u;
		
		
	}

	

}
