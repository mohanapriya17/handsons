package collections2;

public class itemType {
	String name;
	double deposit ,costperday;
	private String getName() {
		return name;
	}
	private void setName(String name) {
		this.name = name;
	}
	private double getDeposit() {
		return deposit;
	}
	private void setDeposit(double deposit) {
		this.deposit = deposit;
	}
	private double getCostperday() {
		return costperday;
	}
	private void setCostperday(double costperday) {
		this.costperday = costperday;
	}
	
	
	public itemType(String name, double deposit, double costperday) {
		super();
		this.name = name;
		this.deposit = deposit;
		this.costperday = costperday;
	}
	@Override
	public String toString() {
		System.out.format("%-20s%-20s%-20s ","Name","Deposit","CostPerday");
		System.out.println(" ");
		System.out.format("%-20s%-20s%-20s",name,deposit,costperday);
		return " ";
	}
	
	

}
