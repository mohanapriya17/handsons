package org.writer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class Logging {
	LogWriter writer;
	
	public Logging() {
		// TODO Auto-generated constructor stub
	}
	
	
	public LogWriter getWriter() {
		return writer;
	}

	@Autowired
	public void setWriter(@Qualifier("consoleWriter") LogWriter writer) {
		this.writer = writer;
	}


	public void writeToConsole(String text) {
		writer.write(text);
	}
	public void writeToFile(String text) {
		writer.write(text);
	}
	
}
