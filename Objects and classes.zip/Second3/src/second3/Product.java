package second3;

public class Product {
	int Product_code;
	String Product_Name;
	public int getProduct_code() {
		return Product_code;
	}
	public void setProduct_code(int product_code) {
		Product_code = product_code;
	}
	public String getProduct_Name() {
		return Product_Name;
	}
	public void setProduct_Name(String product_Name) {
		Product_Name = product_Name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	public String getStatic_name() {
		return static_name;
	}
	public void setStatic_name(String static_name) {
		this.static_name = static_name;
	}
	double price;
	int stock;
	String static_name;
	/**
	 * 
	 */
	public Product() {
		super();
	}
	
	public Product(int product_code, String product_Name, double price, int stock, String static_name) {
		super();
		Product_code = product_code;
		Product_Name = product_Name;
		this.price = price;
		this.stock = stock;
		this.static_name = static_name;
	}
	 public double getDiscountprice() {
		 if(price>=80000) {
			 double discount=30;//30 means 30%
				double discount1=100-discount;
				double prices= (discount*price)/100;
				return prices;
				
		 }
		 else if(price<=60000 && price>=50000) {
				double discount2=20;//20 means 30%
				//double discount21=100-discount2;
				double prices2= (discount2*price)/100;
				return prices2;
		 }
		 else if(price<=50000 && price>50000) {
				double discount3=10;//10 means 10%
				//double discount31=100-discount3;
				double prices3= (discount3*price)/100;
				return prices3;
		 }
	
		
	 else {
		        double discount4=5;//5 means 5%
				//double discount41=100-discount4;
				double prices4= (discount4*price)/100;
				return prices4;
	 }
		 
	 
}
	 public static Product checklessStock(Product[] prod) {
		 int minStock=99999999;
		 Product prod1=new Product();
		 for(int i=0;i<prod.length;i++)
		 {
			 if(prod[i].getStock()<minStock) {
				 minStock=prod[i].getStock();
				 prod1=prod[i];
			 }
			 
		 }
		
		return prod1;
		 
	 }




	 public static String checkprice(Product prod,Product prod1) {
	 if(prod.getPrice()<prod1.getPrice()) {
			
			return prod.getProduct_Name()+"is cheaper";
	 }
		else {
			return prod1.getProduct_Name()+"is cheaper";
		
		}
	 }
	 
			
}

	 
	 
		 
	 
		 

