package org.writer;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Configuration
@ComponentScan(basePackages = {"org.writer"})
@Component
public class LoggerConfig {

	/*
	 * @Bean(name = "consoleWriter") public ConsoleWriter getConsole() {
	 * ConsoleWriter consoleWriter = new ConsoleWriter(); return consoleWriter; }
	 * 
	 * @Bean(name = "fileWriter") public FileWriter getFileWriter() { FileWriter
	 * fileWriter = new FileWriter(); return fileWriter; }
	 * 
	 * @Bean(name = "logging") public Logging getLogging() { Logging logging = new
	 * Logging(); logging.setConsoleWriter(getConsole());
	 * logging.setFileWriter(getFileWriter()); return logging; }
	 */

}
