package third2;

public class savingAccount extends Account{
	double minimumBalance;

	protected double getMinimumBalance() {
		return minimumBalance;
	}

	protected void setMinimumBalance(double minimumBalance) {
		this.minimumBalance = minimumBalance;
	}

	/**
	 * @param account_Number
	 * @param balance
	 * @param accountHolderName
	 * @param minimumBalance
	 */
	protected savingAccount(String account_Number, double balance, String accountHolderName, double minimumBalance) {
		super(account_Number, balance, accountHolderName);
		this.minimumBalance = minimumBalance;
	}

	/**
	 * 
	 */
	protected savingAccount() {
		super();
		// TODO Auto-generated constructor stub
	}

}
