     package fifth4;
import java.util.*;
public class Main {

	public static void main(String[] args) {
     Scanner sc=new Scanner(System.in);
     
     Square sq=new Square();
     Rectangle rect=new Rectangle();
     System.out.println("Enter the length And Breadth");
     double len=sc.nextDouble();
     rect.setLength(len);
     double bre=sc.nextDouble();
     rect.setBreadth(bre);
     System.out.println("Enter the square");
     double si=sc.nextDouble();
     sq.setSide(si);
     rect.calciPeri();
     rect.caluArea();
     sq.calciPeri();
     sq.caluArea();
     
	}

}
