package third4;

public class Rectangle extends Shape {
	double length;
	double breadth;
	
	public void computeArea() {
		area=length*breadth;
		System.out.format("Rectangle:%.2f",area);
	}

	protected double getLength() {
		return length;
	}

	protected void setLength(double length) {
		this.length = length;
	}

	protected double getBreadth() {
		return breadth;
	}

	protected void setBreadth(double breadth) {
		this.breadth = breadth;
	}

	/**
	 * 
	 */
	protected Rectangle() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param length
	 * @param breadth
	 */
	protected Rectangle(double length, double breadth) {
		super();
		this.length = length;
		this.breadth = breadth;
	}
	

}
