package fifth4;

public class Rectangle implements PolygonInterface{
	double breadth,length;
/**
	 * 
	 */
	protected Rectangle() {
		super();
		// TODO Auto-generated constructor stub
	}
/**
	 * @param breadth
	 * @param length
	 */
	protected Rectangle(double breadth, double length) {
		super();
		this.breadth = breadth;
		this.length = length;
	}
protected double getBreadth() {
		return breadth;
	}
	protected void setBreadth(double breadth) {
		this.breadth = breadth;
	}
	protected double getLength() {
		return length;
	}
	protected void setLength(double length) {
		this.length = length;
	}
public void calciPeri() {
		double p=2*(length+breadth);
		System.out.println("Perimeter of rectangle"+p);
		
	}
	public void caluArea() {
		double p=length*breadth;
		System.out.println("area of rectangle"+p);
		
	}


}
