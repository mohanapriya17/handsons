package sixth1;
import java.util.*;
public class Main {

	public static void main(String[] args) {
       Scanner sc=new Scanner(System.in);
       
       System.out.println("Enter Humpty's Sentence :");
       String s1=sc.nextLine();
       System.out.println("Enter Dumpty's Sentence :");
       String s2=sc.nextLine();
       if(s2.contentEquals(s2)) {
    	   System.out.println("found");
       }
       else {
    	   System.out.println("Not found");
       }
	}

}
