package collectionssolve1;

import java.util.Comparator;

public class TicketBooking implements Comparator{
private String Customer;
private Integer price;
public String getCustomer() {
	return Customer;
}
public void setCustomer(String customer) {
	Customer = customer;
}
public Integer getPrice() {
	return price;
}
public void setPrice(Integer price) {
	this.price = price;
}
/**
 * @param customer
 * @param price
 */
public TicketBooking(String customer, Integer price) {
	super();
	Customer = customer;
	this.price = price;
}
/**
 * 
 */
public TicketBooking() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public int compare(Object a, Object b) {
	TicketBooking ticket= (TicketBooking)a;
	TicketBooking ticket1=(TicketBooking)b;
	if(ticket.getPrice()<ticket1.getPrice()) {
		return -1;
	}
	else if(ticket.getPrice()>ticket.getPrice()) {
		return 1;
	}
	else
	{
		return 0;
	}
	
	
}
}
