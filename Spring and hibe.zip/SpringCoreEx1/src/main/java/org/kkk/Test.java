package org.kkk;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("quizAppContext.xml");
		Quiz quiz=context.getBean(Quiz.class, "quiz");
		System.out.println("the question is ");
		System.out.println(quiz.getQuestion());
		Map<String, String> answers=quiz.getAnswers();
		Set<Entry<String, String>> answers1 = answers.entrySet();
		for(Entry<String, String> answer:answers1) {
			System.out.println("the answer is "+answer.getKey());
			System.out.println("answer given by "+answer.getValue());
		}
	}

}
