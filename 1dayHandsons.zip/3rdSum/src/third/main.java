package third;

import java.util.Scanner;

public class main {
	

	public static void main(String[] args) {
		 Scanner sc=new Scanner(System.in);
	        Delivery d=new Delivery();
	        System.out.println("enter the over:");
	        long over=sc.nextLong();
	        System.out.println("enter the ball:");
	        long ball=sc.nextLong();
	        d.setOver(over);
	        System.out.println("enter the runs:");
	        long runs=sc.nextLong();
	        d.setOver(over);
	        d.setBall(ball);
	        d.setRuns(runs);
	        sc.nextLine();
	        System.out.println("enter the batsman:");
	        String batsman=sc.nextLine();
	        d.setBatsman(batsman);
	        System.out.println("enter the bowlerMan:");
	        String bowlerMan=sc.nextLine();
	        d.setBowlerMan(bowlerMan);
	         System.out.println("enter the nonStriker:");
	        String nonStriker=sc.nextLine();
	        d.setNonStriker(nonStriker);
	        d.display();
	        

	}

}
