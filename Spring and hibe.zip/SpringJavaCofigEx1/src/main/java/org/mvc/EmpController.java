package org.mvc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
public class EmpController {
	EmpService service;
	public EmpController() {
		// TODO Auto-generated constructor stub
	}
	public EmpService getService() {
		return service;
	}
	@Autowired
	public void setService(EmpService service) {
		this.service = service;
	}
	public void insert()
	{
		service.insert();
	}
}
