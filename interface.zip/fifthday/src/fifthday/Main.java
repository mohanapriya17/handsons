package fifthday;
import java.util.*;
public class Main {

	public static void main(String[] args) {
       Scanner sc=new Scanner(System.in);
       goldStall gs=new goldStall();
       PerimiumStall ps=new PerimiumStall();
       executiveStall es=new executiveStall();
       int n=0;
		while(n<3) {
			 gs.menu();
	       System.out.println("Enter the Choice");
	       int ch1=sc.nextInt();
	        switch(ch1) {
	        
	        case 1:
	        	
	        	sc.nextLine();
	            System.out.println("Enter the stall details in comma separated by comma(StallName,StallCost,OwnerName,NooftvSets)");
	            String details=sc.nextLine();
	            String [] str=details.split(",");
	            for(String oo:str)
	            	System.out.println(" ");
	            String sname=str[0];
	            gs.setStallName(sname);
                Integer scost=Integer.parseInt(str[1]);
                gs.setCost(scost);
                String OwnerName=str[2];
                gs.setOwnerName(OwnerName);
                Integer Tvsets=Integer.parseInt(str[3]);
                gs.setTvSet(Tvsets);
                gs.display();
               // gs.menu();
                break;
                
	        case 2:
	        	sc.nextLine();
	            System.out.println("Enter the stall details in comma separated by comma(StallName,StallCost,OwnerName,No Of Projectors)");
	            String details1=sc.nextLine();
	            String [] str1=details1.split(",");
	            for(String oo:str1)
	            	System.out.println(" ");
	            String sname1=str1[0];
	           ps.setStallName(sname1);;
                Integer scost1=Integer.parseInt(str1[1]);
              ps.setCost(scost1);
                String OwnerName1=str1[2];
                ps.setOwnerName(OwnerName1);
                Integer projectors=Integer.parseInt(str1[3]);
               ps.setProjector(projectors);
                ps.display();
                break;
                
	        case 3:
	        	sc.nextLine();
	            System.out.println("Enter the stall details in comma separated by comma(StallName,StallCost,OwnerName,NoofScreens)");
	            String details2=sc.nextLine();
	            String [] str2=details2.split(",");
	            for(String oo:str2)
	            	System.out.println(" ");
	            String sname2=str2[0];
	            es.setStallName(sname2);
                Integer scost2=Integer.parseInt(str2[1]);
                es.setCost(scost2);
                String OwnerName2=str2[2];
               es.setOwnerName(OwnerName2);
                Integer screen=Integer.parseInt(str2[3]);
                es.setScreen(screen);
                es.display();
                break;
                
                
	        
	        
       
	}
	        n++;

}
	}
} 
