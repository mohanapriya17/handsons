package seventh;
import java.util.*;
public class main {

	public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        Delivery d=new Delivery();
        System.out.println("Enter the over :");
        long over=sc.nextLong();
        d.setOver(over);
        System.out.println("Enter the ball :");
        long ball=sc.nextLong();
        d.setBall(ball);
        System.out.println("Enter the runs");
        long runs=sc.nextLong();
        d.setRuns(runs);
        sc.nextLine();
        System.out.println("Enter the batsman :");
        String batsman=sc.nextLine();
        d.setBatsman(batsman);
        System.out.println("Enter the bowlername :");
        String bowlername=sc.nextLine();
      d.setBowlerMan(bowlername);
        System.out.println("Enter the Striker :");
        String nonstriker=sc.nextLine();
        d.setNonStriker(nonstriker);
        System.out.println("over : "+d.getOver());
        System.out.println("ball : "+d.getBall());
        System.out.println("runs : "+d.getRuns());
        System.out.println("batsman : "+d.getBatsman());
        System.out.println("bowlername : "+d.getBowlerMan());
        System.out.println("Nonstriker : "+d.getNonStriker());
        
        
        
        
	}

}
