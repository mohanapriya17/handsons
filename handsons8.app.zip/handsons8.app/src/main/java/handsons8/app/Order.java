package handsons8.app;

public class Order {
	private String itemName;
	private double price;
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Order(String itemName, double price) {
		super();
		this.itemName = itemName;
		this.price = price;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public void display() {
		System.out.println("Item Name : "  + this.getItemName() 
							+"\nPrice : " + this.getPrice());
		
	}

}
