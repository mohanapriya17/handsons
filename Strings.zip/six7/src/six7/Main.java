package six7;
import java.util.*;
public class Main {

	public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter Humpty's Sentence :");
        String s1= sc.nextLine();
        System.out.println("Converted String :"+s1.toUpperCase());
        
        
	}

}
