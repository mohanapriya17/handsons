package fifthday;
interface stall{
	void display();
}
public class firstInterface {

}
