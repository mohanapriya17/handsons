package org.ekart;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.List;

public class Cashier {
	private String filePath;
	private ShoppingCart cart;
	public Cashier() {
		// TODO Auto-generated constructor stub
	}
	public Cashier(String filePath, ShoppingCart cart) {
		super();
		this.filePath = filePath;
		this.cart = cart;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public ShoppingCart getCart() {
		return cart;
	}
	public void setCart(ShoppingCart cart) {
		this.cart = cart;
	}
	public void generateBill() throws FileNotFoundException {
		double totalBill=0;
		PrintWriter pw=new PrintWriter(filePath);
		List<Product> products=cart.getProducts();
		pw.println("pid\tpname\tprice");
		pw.println("------------------------------");
		for(Product product:products) {
			totalBill=totalBill+product.getPrice();
			pw.println(product.getPid()+"\t"+product.getProductName()+"\t"+product.getPrice());
			
		}
		pw.println("The total bill is "+totalBill);
		System.out.println("bill generated successfully");
		pw.flush();
		pw.close();
		
	}
	
}
