package org.ekart;

import java.io.FileNotFoundException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) throws FileNotFoundException {
		ApplicationContext context=new ClassPathXmlApplicationContext("shoppingCartAppContext.xml");
		Cashier cashier=context.getBean(Cashier.class,"cashier");
		cashier.generateBill();
	}

}
