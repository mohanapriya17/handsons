package collectionssolve3;

import java.io.*;
import java.util.*;

public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		List<Hall> list=new ArrayList();
         System.out.println("Enter the Number of halls");
         int n=Integer.parseInt(br.readLine());
         if(n>0) {
        	 for(int i=0;i<n;i++) {
        		 System.out.println("Enter the details of hall "+i);
        		 String s=br.readLine();
        		 String []st=s.split(",");
        		 list.add(new Hall(st[0],st[1],st[2],Double.parseDouble(st[3])));
        		 
        	 }
        	 System.out.println("Sorted Order (from the least expensive to the most):");
         }
         Collections.sort(list);
         Iterator<Hall> it=list.iterator();
         System.out.format("%-15s%-15s%-15s%-15s","Name","Type","Details","Costperday");
         System.out.println();
         while(it.hasNext()) {
        	 Hall h=it.next();
        	 System.out.println(h);
        	 
        	 
         }
         
         
         
         
	}

}
