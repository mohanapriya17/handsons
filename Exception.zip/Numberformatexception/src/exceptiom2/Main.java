package exceptiom2;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
public class Main {

	public static void main(String[] args) throws IOException {
    
     
     try {
     System.out.println("Enter the item type details");
    
     System.out.println("Enter the name");
     BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
     String name=br.readLine();
  
     System.out.println("Enter the deposit");
     double deposit=Double.parseDouble(br.readLine());
    
     System.out.println("Enter the cost");
     double cost=Double.parseDouble(br.readLine());
     
     itemType it=new itemType(name,deposit,cost);
     String d=it.toString();
     System.out.println( it.getName());
     System.out.println(it.getDeposit());
     System.out.println(it.getCostPerDay());
 
     }
     catch(NumberFormatException e) {
    	 System.out.println(e);
    	 
     }
	}

}
