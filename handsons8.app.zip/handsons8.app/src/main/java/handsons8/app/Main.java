package handsons8.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {

	public static void main(String[] args) {
	ApplicationContext appContext = new AnnotationConfigApplicationContext(AppConfigure.class);
		
		User user = appContext.getBean("user",User.class);
		user.display();
		((AnnotationConfigApplicationContext)appContext).close();
	}

	}


