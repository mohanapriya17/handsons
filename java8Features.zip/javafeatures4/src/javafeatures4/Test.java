package javafeatures4;

import java.io.*;
import java.util.ArrayList;
import java.util.function.Function;

public class Test {

	private static final String I = null;

	public static void main(String[] args) {
         // BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
          ArrayList<solve> l= new ArrayList<solve>();
          populate(l);
          Function<solve,String> string=str->{
        	  int marks=str.getMarks();
        	  if(marks>80) {
        		  return "A";
        	  }
        	  else if(marks<80 && marks>60) {
        		  return "B";
        	  }
        	  else if(marks<60 && marks>35) {
        		  return "C";
        	  }
        	  else {
        		  return "Invalid ";
        	  }
        	  
        	  
          };
          
        for(solve s:l) {
        	
			System.out.println("Student Name:"+s.getName());
			System.out.println("Student MArks"+s.getMarks());
			System.out.println("Student grade"+string.apply(s));
        	
        }
          
          
          
	}

	private static void populate(ArrayList<solve> l) {
		l.add(new solve("maven",60));
		l.add(new solve("joongki",89));
		l.add(new solve("divya",60));
		l.add(new solve("aera",45));
		
	}

}
