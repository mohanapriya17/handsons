package exceptions;

import java.util.Scanner;

public class IllegalArgumentException extends Exception {

	public static void main(String[] args) {
         int []a=new int[10];
         Scanner sc=new Scanner(System.in);
         System.out.println("Enter any 10 values :");
         for(int i=0;i<10;i++) {
        	 a[i]=sc.nextInt();
        	 
         }
         System.out.println("Enter Divisor :");
         int b=sc.nextInt();
         try {
        	 for(int i=0;i<10;i++) {
        		 if((b%2==0)&&(a[i]%2!=0)){
        			 throw new IllegalArgumentException();
        		 }
        		 else if((b%2!=0) &&(a[i]%2!=0)) {
        			 throw new IllegalArgumentException();
        		 }
        		 else {
        			 System.out.println("Output With Exception Handling :"+a[i]/b);
        		 }
        	 }
         }
         catch(IllegalArgumentException e) {
        	 System.out.println("Exception allowed");
        	 for(int i=0;i<10;i++) {
        		 System.out.println("Result :");
        	 }
        	 
         }
         
	}

}
