package eight;

public class Wicked {
long over;
long ball;
String wikeType;
String bowlerName;
public long getOver() {
	return over;
}
public void setOver(long over) {
	this.over = over;
}
public long getBall() {
	return ball;
}
public void setBall(long ball) {
	this.ball = ball;
}
public String getWikeType() {
	return wikeType;
}
public void setWikeType(String wikeType) {
	this.wikeType = wikeType;
}
public String getBowlerName() {
	return bowlerName;
}
public void setBowlerName(String bowlerName) {
	this.bowlerName = bowlerName;
}
public String getPlayerMan() {
	return PlayerMan;
}
public void setPlayerMan(String playerMan) {
	PlayerMan = playerMan;
}
/**
 * 
 */
public Wicked() {
	super();
	// TODO Auto-generated constructor stub
}
String PlayerMan;
}
