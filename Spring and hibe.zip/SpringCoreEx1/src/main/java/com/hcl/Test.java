package com.hcl;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext1.xml");
		User user=context.getBean(User.class,"user");
		Role role=user.getRole();
		System.out.println(user.getUserName()+"\t"+user.getPassword());
		System.out.println(role.getName()+"\t"+role.getRole_id());
		((ClassPathXmlApplicationContext)context).close();
	}

}
