package exceptions3;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
      try {
    	  int a[]=new int[10];
    	  Scanner sc=new Scanner(System.in);
    	  System.out.println("Enter any 10 values :");
    	 
    	  for(int i=0;i<a.length;i++) {
    		  a[i]=sc.nextInt();
    		  
    	  }
    	  System.out.println("Enter Divisor :");
    	  int n=sc.nextInt();
    	  for(int j=0;j>0;j++) {
    		  int result=a[j-1]/n;
    		  System.out.println("Result :");
    	  }
      }
      catch(ArithmeticException e) {
    	  System.out.println("Exception handled in the main() method");
      }
	}

}
