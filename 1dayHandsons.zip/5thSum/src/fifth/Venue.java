package fifth;

public class Venue {
private String name;
private String city;
/**
 * 
 */
public Venue() {
	super();
	// TODO Auto-generated constructor stub
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
void menu() {
	System.out.println("verify and update details");
	System.out.println("Menu");
	System.out.println("1.Update venue name");
	System.out.println("2.Update city name");
	System.out.println("3.All Informations correct/exit");
	  System.out.println("Type 1 or 2 or 3");
}
}
