package fifth5;

public class CarService implements Car {
	 public void sum(int num) {
		int sum=0;
		int rem=0;
		rem=num%10;
		sum=sum+rem;
		num=num/10;
		if(sum%2==0) {
			System.out.println("you can go on tuesday,thursday and saturday");
		}
		else {
			System.out.println("you can go on servicing Monday ,wednesday and friday");
		}
		 
	 }
	 public void year(int years) {
		 if(years<5) {
			 System.out.println("car washing is free");
			 
		 }
		 else {
			 System.out.println("car washing shooudl be payed");
		 }
		 
	 }
		public void brand(String brand) {
			if(brand.equals("maruthi")) {
				double d=5000-(0.05*5000);
				System.out.println("your servicing charges are"+d);
			}
			else {
				System.out.println("Your servicing charges "+5000);
			}
		}

}
