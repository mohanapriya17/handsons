package collectionssolve1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
     List<TicketBooking> list=new ArrayList<>();
     System.out.println("Enter the Number of customers  :");
     int n=Integer.parseInt(br.readLine());
     if(n>0) {
    	 for(int i=0;i<n;i++) {
    	 System.out.println("Enter the booking price accordingly with customer name in CSV(Customer Name,Price)");
    	 String details=br.readLine();
    	 String[] a=details.split(",");
    	 String name=a[0];
    	 Integer price=Integer.parseInt(a[1]);
    	 list.add(new TicketBooking(name,price));
     }
     Comparator c=new TicketBooking();
     TicketBooking t1=Collections.min(list,c);
     System.out.println(t1.getCustomer()+"spends minimum amount of Rs."+t1.getPrice());
     TicketBooking t2=Collections.max(list, c);
     System.out.println(t2.getCustomer()+"spends maximum amount of Rs."+t2.getPrice());
     
	}
	else {
		System.out.println("Invalid Output");
	}
		
     
     
     
	}

}
