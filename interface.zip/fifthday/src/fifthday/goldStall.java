package fifthday;

public class goldStall implements stall{
	private String stallName;
	private Integer cost;
	private String ownerName;
	private Integer tvSet;
	
	
	protected goldStall(String stallName, Integer cost, String ownerName, Integer tvSet) {
		super();
		this.stallName = stallName;
		this.cost = cost;
		this.ownerName = ownerName;
		this.tvSet = tvSet;
	}


	protected goldStall() {
		super();
	}


	protected String getStallName() {
		return stallName;
	}

	protected void setStallName(String stallName) {
		this.stallName = stallName;
	}


	protected Integer getCost() {
		return cost;
	}

	protected void setCost(Integer cost) {
		this.cost = cost;
	}

	protected String getOwnerName() {
		return ownerName;
	}


	protected void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	protected Integer getTvSet() {
		return tvSet;
	}

	protected void setTvSet(Integer tvSet) {
		this.tvSet = tvSet;
	}

public void menu() {
	System.out.println("\nEnter the Choose Type ");
	System.out.println("1) Gold Stall");
	System.out.println("2) Perimium Stall");
	System.out.println("3) Executive Stall");
}
	public void display() {
		
		System.out.println("The Stall Type        :"+stallName);
		System.out.println("Cost      :"+cost+"Rs.");
		System.out.println("OWNER_NAME     "+ownerName);
		System.out.println("No of Tv Sets     "+tvSet);
		
	
	}

}
