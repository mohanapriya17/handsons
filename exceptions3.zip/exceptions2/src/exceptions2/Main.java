package exceptions2;
import java.util.*;
public class Main {

	public static void main(String[] args) throws IllegalArgumentException {
      int a[]=new int[10];
      Scanner sc=new Scanner(System.in);
      
      System.out.println("Enter any 10 values :");
      for(int i=0;i<10;i++) {
    	  a[i]=sc.nextInt();
    	  
      }
      System.out.println("Enter Divisor :");
      int d=sc.nextInt();
      try {
    	  for(int i=0;i<10;i++) {
    		  if((d%2==0)&& (a[i]%2!=0)){
    			  throw new IllegalArgumentException();
    		  }
    		  else if((d%2 !=0)&&a[i]%2==0) {
    			  throw new IllegalArgumentException();
    		  }
    		  else {
    			  System.out.println("Result :"+a[i]/d);
    		  }
    	  }
      }
      catch(IllegalArgumentException e) {
    	  System.out.println("Exception handled in the method");
    	  for(int i=0;i<10;i++) {
    		  for(int j=0;j<=i;j++) {
    		  System.out.println("Result :"+j);
    	  }
    		  System.out.println("Result :"+i);
      }
	}

	}
}
