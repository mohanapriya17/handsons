package collections9;

import java.io.*;
import java.util.*;

public class Main {

	public static void main(String[] args) throws IOException {
		List<User> list=new ArrayList<>();
		UserBO ub=new UserBO();
		ub.addAll(ub.getList());
       BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
       System.out.println("Enter the number of User details to be added");
       int s=Integer.parseInt(br.readLine());
       if(s>0) {
    	   for(int i=0;i<s;i++) {
    		   System.out.println("Enter the user 1 detail in csv format");
    		   String st=br.readLine();
    		   String[] str=st.split(",");
    		   ub.add(new User(str[0],str[1],str[2],str[3]));
    		   
    		   
    	   }
    	   Iterator<User> it=ub.iterator();
    	   User use=new User();
    	   System.out.format("%-20s%-20s%-20s%-20s","name","contactNumber","username","email");
    	   System.out.println();
    	   while(it.hasNext()) {
    		   User uses=it.next();
    		   uses.display();
    	   }
    	   System.out.println("Enter the range to be removed");
    	   int a=Integer.parseInt(br.readLine());
    	   int b=Integer.parseInt(br.readLine());
    	   ub.remove(a, b);
       }
       
	}

}
