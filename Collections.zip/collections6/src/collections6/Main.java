package collections6;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Iterator;

public class Main {

	public static void main(String[] args) throws IOException {
       HashSet<String> s=new HashSet();
       BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the UserName");
		String s1=br.readLine();
		s.add(s1);
		
		while(true) {
			
			System.out.println("Do you want to continue(y/n)");
			String str=br.readLine();
			if(str.equals("y")) {
				System.out.println("Enter the UserNAme");
				String s3=br.readLine();
				s.add(s3);
			}
		
  	  else {
  		  break;}
		}
			int size=s.size();
			
	    	  System.out.println("There are"+size+"no.of uniques names");
	    	 
			
			
			
		}
       
	}
	



