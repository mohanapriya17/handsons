package javafeatures3;

import java.io.IOException;
import java.util.function.Function;

public class solve {
	

	public static void main(String[] args) throws IOException {
		String s="durga software solutions hyderabad "; 
		Function<String,Integer> f= s1->s1.length() - s1.replaceAll(" ","").length(); 
		System.out.println(f.apply(s));
}
}