package collectionssolve;

public class User {
private String name,email,username,password;
}
