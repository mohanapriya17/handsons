package third4;
import java.util.*;
public class Main {

	public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        Shape sh=new Shape();
        Circle cc=new Circle();
        Rectangle r=new Rectangle();
        Triangle t=new Triangle();
        int n=0;
        while(n<3) {
        System.out.println("\nenter the choice");
        int ch=sc.nextInt();
        sh.menu();
        switch(ch) {
        
        case 1:
            System.out.println("\nenter the rad");
            double rad=sc.nextDouble();
            
            sc.hasNextLine();
            cc.setRadius(rad);
            cc.computeArea();
            break;
        case 2:
           System.out.println("\nenter the values");
            double leng=sc.nextDouble();
            r.setLength(leng);
            double brea=sc.nextDouble();
            r.setBreadth(brea);
            r.computeArea();
            break;
        case 3:
        	  System.out.println("enter the values");
            double base =sc.nextDouble();
            t.setBase(base);
            double ht=sc.nextDouble();
            t.setHeight(ht);
            t.computeArea();
           
            break;
           
        
        
	}
        n++;

}
	}
}
