package com.ksr;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("collegeAppContext.xml");
		College college=context.getBean(College.class,"college");
		System.out.println(college.getCid()+"\t"+college.getCollegeName());
		System.out.println("the available courses are");
		List<Course> courses=college.getCourses();
		for(Course course:courses)
		{
			System.out.println(course.getCid()+"\t"+course.getCname()+"\t"+course.getDuration());
		}
		((ClassPathXmlApplicationContext)context).close();
	}

}
