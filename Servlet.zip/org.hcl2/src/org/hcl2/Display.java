package org.hcl2;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Display
 */
@WebServlet("/Display")
public class Display extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Display() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter printwriter=response.getWriter();
		String name=request.getParameter("name");
		String PhoneNumber=request.getParameter("phonenumber");
		String Email=request.getParameter("email");
		String city=request.getParameter("city");
		printwriter.write("<html>");
		printwriter.write("<head>");
		printwriter.write("<h1>The User details are");
		
		printwriter.write("<body>");
		
		printwriter.write("<table border='1'>");
		printwriter.write("<tr>");
		printwriter.write("<td>Name</td><td>PhoneNumber</td><td>Email</td><td>City</td>");
		printwriter.write("</tr>");
		printwriter.write("<tbody>");
		printwriter.write("<tr>");
		printwriter.write("<td>"+name+"</td><td>"+PhoneNumber+"</td><td>"+Email+"</td><td>"+city+"</td>");
		printwriter.write("</tr>");
		printwriter.write("</tbody>");
		printwriter.write("</table>");
		
		
        
		printwriter.close();
		
		
	}

}
