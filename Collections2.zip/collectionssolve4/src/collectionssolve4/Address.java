package collectionssolve4;

public class Address implements Comparable{
private String username,addressLine1,addrressLine2;
private Integer pincode;

public String getUsername() {
	return username;
}

public void setUsername(String username) {
	this.username = username;
}

public String getAddressLine1() {
	return addressLine1;
}

public void setAddressLine1(String addressLine1) {
	this.addressLine1 = addressLine1;
}

public String getAddrressLine2() {
	return addrressLine2;
}

public void setAddrressLine2(String addrressLine2) {
	this.addrressLine2 = addrressLine2;
}

public Integer getPincode() {
	return pincode;
}

public void setPincode(Integer pincode) {
	this.pincode = pincode;
}


/**
 * @param username
 * @param addressLine1
 * @param addrressLine2
 * @param pincode
 */
public Address(String username, String addressLine1, String addrressLine2, Integer pincode) {
	super();
	this.username = username;
	this.addressLine1 = addressLine1;
	this.addrressLine2 = addrressLine2;
	this.pincode = pincode;
}


/**
 * 
 */
public Address() {
	super();
	// TODO Auto-generated constructor stub
}


@Override
public String toString() {
	System.out.println(username +"\t"+addressLine1+"\t"+addrressLine2+"\t"+pincode);
	System.out.println();
	return "";
}

@Override
public int compareTo(Object obj) {
	Address add=(Address)obj;
	if(add.getPincode()<pincode) {
		return 1;
	}
	else if(add.getPincode()>pincode) {
		return -1;
		
	}
	else {
	return 0;
}
}
}

