package colectionssolve7;
import java.io.*;
import java.util.*;
public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
      BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
      List<User> list=new ArrayList();
      LinkedHashMap<String,String> map=new LinkedHashMap();
      System.out.println("Enter the number of users:   ");
     int n=Integer.parseInt(br.readLine());
     if(n>0) {
    	 for(int i=0;i<n;i++) {
    		 System.out.println("Enter the details of User"+i);
    		 String s=br.readLine();
    		 String []st=s.split(",");
    		 list.add(new User(st[0],st[1],st[2],st[3]));
    	 
    	 }
    	 
    	 Collections.sort(list);
    	 Collections.reverse(list);
    	 System.out.println("The user details in reverse order:");
    	 System.out.format("%-15s%-15s","Name","MobileNumber");
    		System.out.println("");
    		for(int i=0;i<n;i++) {
    			
    			map.put(list.get(i).getName(), list.get(i).getMobileNumber());
    			
    		}
    		Set s=map.entrySet();
    		Iterator<LinkedHashMap> it=s.iterator();
    		while(it.hasNext()) {
    			Map.Entry h=(Map.Entry)it.next();
    			System.out.format("%-15s%-15s",h.getKey(),h.getValue());
    			System.out.println();
    		}
    		
     }
     
	}

}
