package org.hcl1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Exhibition
 */
@WebServlet("/Exhibition")
public class Exhibition extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Exhibition() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter printwriter=response.getWriter();
		printwriter.write("<html>");
		printwriter.write("<head>");
		printwriter.write("<body>");
		printwriter.write("<h1 style=\"text-align:center; color:pink;\">TEXT FAIR 2018 EXPO</h1>");
		printwriter.write("<div Style=\"text-align:center;\">");
		printwriter.write("<table style=\"width:75%\">");
		printwriter.write("<tr>");
		printwriter.write("<th>Name:</th>");
		printwriter.write("<td>Text fair 2017 expo</td>");
		
		printwriter.write("<tr>");
		printwriter.write("<th>HallName:</th>");
		printwriter.write("<td>pvr Superlux</td>");
		printwriter.write("<tr>");
		printwriter.write("<th>Start Date:</th>");
		printwriter.write("<td>10-10-2020</td>");
		printwriter.write("<tr>");
		
		printwriter.write("<th>End Date:</th>");
		printwriter.write("<td>10-10-2030</td>");
		
		
	}

}
