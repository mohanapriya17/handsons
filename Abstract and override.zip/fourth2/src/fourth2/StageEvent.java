package fourth2;

public class StageEvent extends Event{
	Integer NoOfShows;
	Integer NoOfSeatPerShow;
	
	protected Integer getNoOfShows() {
		return NoOfShows;
	}
	protected void setNoOfShows(Integer noOfShows) {
		NoOfShows = noOfShows;
	}
	protected Integer getNoOfSeatPerShow() {
		return NoOfSeatPerShow;
	}
	protected void setNoOfSeatPerShow(Integer noOfSeatPerShow) {
		NoOfSeatPerShow = noOfSeatPerShow;
	}
	/**
	 * 
	 */
	protected StageEvent() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param name
	 * @param details
	 * @param ownerName
	 */
	protected StageEvent(String name, String details, String ownerName) {
		super(name, details, ownerName);
		// TODO Auto-generated constructor stub
	}
	public Double Projectedrevenue(Integer noOfShows,Integer noOfSeatPerShow) {
		double events= 50*noOfShows*noOfSeatPerShow;
		
		
		
		return events;
		
	}
		}


