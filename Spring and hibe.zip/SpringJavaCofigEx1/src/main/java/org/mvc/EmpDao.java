package org.mvc;

import org.springframework.stereotype.Repository;

@Repository
public class EmpDao {
	public void insertData()
	{
		System.out.println("Data is inserting...");
	}
}
