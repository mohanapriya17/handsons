package fifth3;
interface MutualFund{
	abstract public void duration(); 
	abstract public void amount();
		
	
}
public class FirstcClass {
	
	

}
