package fourth2;

public class Event {
	String name;
	String details;
	String OwnerName;
	protected String getName() {
		return name;
	}
	/**
	 * @param name
	 * @param details
	 * @param ownerName
	 */
	protected Event(String name, String details, String ownerName) {
		super();
		this.name = name;
		this.details = details;
		OwnerName = ownerName;
	}
	protected void setName(String name) {
		this.name = name;
	}
	protected String getDetails() {
		return details;
	}
	protected void setDetails(String details) {
		this.details = details;
	}
	protected String getOwnerName() {
		return OwnerName;
	}
	protected void setOwnerName(String ownerName) {
		OwnerName = ownerName;
	}
	/**
	 * 
	 */
	protected Event() {
		super();
		// TODO Auto-generated constructor stub
	}
	void menu() {
		System.out.println("Enter the Type of the event");
		System.out.println("1.Exhibition");
		System.out.println("2.StageEvent");
	}

}
