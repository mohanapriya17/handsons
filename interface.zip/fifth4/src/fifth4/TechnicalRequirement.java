package fifth4;
interface PolygonInterface{
	void calciPeri();
	void caluArea();
}
public class TechnicalRequirement {

}
